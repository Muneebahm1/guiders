<?php

namespace App\Http\Controllers;

use App\Models\Lead;
use App\Models\LeadDocument;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class LeadDocumentController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:counselor');
    }

    public function store(Request $request, Lead $lead)
    {
        $this->authorizeLead($lead);

        $request->validate([
            'document_type' => ['required', 'string', 'in:' . implode(',', LeadDocument::DOCUMENT_TYPES)],
            'file' => ['required', 'file', 'max:10240'], // Max 10MB
            'notes' => ['nullable', 'string'],
        ]);

        $file = $request->file('file');
        $fileName = time() . '_' . $file->getClientOriginalName();
        $filePath = $file->storeAs('lead_documents', $fileName, 'public');

        $document = LeadDocument::create([
            'lead_id' => $lead->id,
            'counselor_id' => Auth::id(),
            'document_type' => $request->document_type,
            'file_name' => $file->getClientOriginalName(),
            'file_path' => $filePath,
            'file_size' => $file->getSize(),
            'mime_type' => $file->getMimeType(),
            'notes' => $request->notes,
        ]);

        return response()->json([
            'success' => true,
            'document' => $document,
            'url' => Storage::url($filePath),
        ]);
    }

    public function destroy(LeadDocument $document)
    {
        $this->authorizeDocument($document);

        Storage::disk('public')->delete($document->file_path);
        $document->delete();

        return response()->json(['success' => true]);
    }

    private function authorizeLead(Lead $lead): void
    {
        if ($lead->counselor_id !== Auth::id()) {
            abort(403);
        }
    }

    private function authorizeDocument(LeadDocument $document): void
    {
        if ($document->counselor_id !== Auth::id()) {
            abort(403);
        }
    }
}
