@extends('layouts.app')

@section('title', 'My Progress')
@section('subtitle', 'Where your case stands right now')

@section('content')
    @if (! $student)
        <p class="text-muted">No student profile found.</p>
    @else
        <div class="readonly-banner">
            This is read-only. Your counselor updates each stage as your case moves forward &mdash; reach out to them with questions.
        </div>

        <div class="panel">
            <div class="panel-head">
                <div>
                    <h2>Study Abroad &mdash; {{ $student->opportunity->name ?? 'No program assigned yet' }}</h2>
                    <p>Counselor: {{ $student->counselor->name ?? 'Not yet assigned' }}</p>
                </div>
            </div>

            @php
                $steps = [
                    ['label' => 'Application Submitted'],
                    ['label' => 'Waiting for Acceptance'],
                    ['label' => 'Accepted'],
                    ['label' => 'Fee Paid', 'date' => $student->fee_date?->toDateString()],
                    ['label' => 'Visa Documentation'],
                    ['label' => 'Visa Process', 'date' => $student->visa_date?->toDateString()],
                    ['label' => 'Visa Approved'],
                    ['label' => 'Traveling'],
                ];

                $currentIndex = match(true) {
                    $student->app_stage === 'Not Applied' => -1,
                    $student->app_stage === 'Submitted' => 0,
                    $student->app_stage === 'Waiting for Acceptance' => 1,
                    $student->app_stage === 'Rejected' => 0,
                    default => match($student->visa_stage) {
                        'Not Started' => 2,
                        'Fee Paid' => 3,
                        'Visa Documentation' => 4,
                        'Visa Process' => 5,
                        'Visa Approved' => 6,
                        'Traveling' => 7,
                        'Visa Rejected' => 5,
                        default => 2,
                    },
                };

                $rejected = $student->app_stage === 'Rejected' ? 1 : ($student->visa_stage === 'Visa Rejected' ? 6 : -1);
            @endphp

            <div class="timeline">
                @foreach ($steps as $i => $step)
                    @php
                        $state = $rejected === $i ? 'rejected' : ($i < $currentIndex ? 'done' : ($i === $currentIndex ? 'current' : ''));
                    @endphp
                    <div class="tl-step {{ $state }}">
                        <div class="tl-line"></div>
                        <div class="tl-dot">{{ $state === 'done' ? '✓' : ($state === 'rejected' ? '✕' : $i + 1) }}</div>
                        <div class="tl-body">
                            <div class="tl-title">{{ $step['label'] }}</div>
                            @if (!empty($step['date']))
                                <div class="tl-date">{{ $step['date'] }}</div>
                            @endif
                            @if ($state === 'current')
                                <div class="tl-note">In progress</div>
                            @endif
                            @if ($state === 'rejected')
                                <div class="tl-note">Not moving forward at this stage</div>
                            @endif
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    @endif
@endsection
