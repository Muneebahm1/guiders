@extends('layouts.app')

@section('title', auth()->user()->hasBackOfficeAccess() ? 'Study Abroad — All Students' : 'My Study Abroad Students')
@section('subtitle', auth()->user()->hasBackOfficeAccess() ? 'Application through visa, across all counselors' : 'Click a status to move it to the next stage')

@section('content')
    @if (auth()->user()->isCounselor() && $unassigned->isNotEmpty())
        <div class="panel">
            <div class="panel-head">
                <div><h2>Unassigned students</h2><p>Self-registered, not yet claimed by a counselor</p></div>
            </div>
            <ul class="list-group list-group-flush">
                @foreach ($unassigned as $student)
                    <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <span>{{ $student->name }}</span>
                        <form method="POST" action="{{ route('students.claim', $student) }}" class="d-flex gap-2">
                            @csrf
                            <select name="opportunity_id" class="form-select form-select-sm">
                                <option value="">Choose program/journal&hellip;</option>
                                @foreach ($opportunities as $opportunity)
                                    <option value="{{ $opportunity->id }}">{{ $opportunity->name }}</option>
                                @endforeach
                            </select>
                            <button class="btn btn-sm btn-outline-primary" type="submit">Claim</button>
                        </form>
                    </li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="panel">
        <div class="panel-head">
            <div><h2>Students</h2><p>&nbsp;</p></div>
            @if (auth()->user()->isCounselor())
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-toggle="collapse" data-bs-target="#waComposer">
                    &#128172; Send Reminder
                </button>
            @endif
        </div>

        @if (auth()->user()->isCounselor())
            <div class="collapse" id="waComposer">
                <div class="p-3 border-bottom" style="background:#F0FBF7">
                    <textarea id="waMessage" class="form-control mb-2" rows="2">Hi {name}, reminder that your {program} deadline is coming up — let's make sure everything is submitted on time.</textarea>
                    <div class="d-flex gap-2 align-items-center flex-wrap">
                        <button id="waSendBtn" class="btn btn-sm btn-primary" type="button">Send via WhatsApp to Selected</button>
                        <span id="waCount" class="text-muted small">0 selected</span>
                    </div>
                    <div id="waConfirm" class="small text-success mt-2" style="display:none"></div>
                </div>
            </div>
        @endif

        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        @if (auth()->user()->isCounselor())
                            <th class="check-col"><input type="checkbox" id="checkAll"></th>
                        @endif
                        <th>Student</th>
                        @if (auth()->user()->hasBackOfficeAccess())
                            <th>Counselor</th>
                        @endif
                        <th>Program</th>
                        <th>Application</th>
                        <th>Fee</th>
                        <th>Visa</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($students as $student)
                        @php
                            $appClass = match($student->app_stage) {
                                'Accepted' => 'teal',
                                'Rejected' => 'coral',
                                'Not Applied' => 'gray',
                                default => 'amber',
                            };
                            $visaClass = match($student->visa_stage) {
                                'Visa Approved', 'Traveling' => 'teal',
                                'Visa Rejected' => 'coral',
                                'Not Started' => 'gray',
                                default => 'amber',
                            };
                        @endphp
                        <tr data-name="{{ $student->name }}" data-program="{{ $student->opportunity->name ?? '' }}">
                            @if (auth()->user()->isCounselor())
                                <td><input type="checkbox" class="student-check" value="{{ $student->id }}"></td>
                            @endif
                            <td class="name-cell">{{ $student->name }}</td>
                            @if (auth()->user()->hasBackOfficeAccess())
                                <td>{{ $student->counselor->name ?? ($student->partner ? 'Partner: '.$student->partner->name : '—') }}</td>
                            @endif
                            <td>{{ $student->opportunity->name ?? '—' }}</td>
                            <td>
                                <span class="chip app-stage-chip {{ $appClass }}"
                                      data-url="{{ route('students.cycle-app-stage', $student) }}">
                                    {{ $student->app_stage }}
                                </span>
                            </td>
                            <td class="date-cell fee-date">{{ $student->fee_date?->toDateString() ?? '—' }}</td>
                            <td>
                                <span class="chip visa-stage-chip {{ $visaClass }}"
                                      data-url="{{ route('students.cycle-visa-stage', $student) }}">
                                    {{ $student->visa_stage }}
                                </span>
                                <div class="sub-cell visa-date">
                                    @if ($student->visa_date) Filed {{ $student->visa_date->toDateString() }} @endif
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="7" class="empty-state">No students yet.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
@endsection

@push('scripts')
<script>
    $(function () {
        const allColors = ['teal', 'coral', 'gray', 'amber'];
        const appColors = { Accepted: 'teal', Rejected: 'coral', 'Not Applied': 'gray' };
        const visaColors = { 'Visa Approved': 'teal', 'Traveling': 'teal', 'Visa Rejected': 'coral', 'Not Started': 'gray' };

        $(document).on('click', '.app-stage-chip', function () {
            const $chip = $(this);
            $.ajax({ url: $chip.data('url'), method: 'PATCH', success: function (data) {
                $chip.text(data.app_stage);
                $chip.removeClass(allColors.join(' ')).addClass(appColors[data.app_stage] || 'amber');
            }});
        });

        $(document).on('click', '.visa-stage-chip', function () {
            const $chip = $(this);
            $.ajax({ url: $chip.data('url'), method: 'PATCH', success: function (data) {
                $chip.text(data.visa_stage);
                $chip.removeClass(allColors.join(' ')).addClass(visaColors[data.visa_stage] || 'amber');
                const $row = $chip.closest('tr');
                if (data.fee_date) $row.find('.fee-date').text(data.fee_date);
                if (data.visa_date) $row.find('.visa-date').text('Filed ' + data.visa_date);
            }});
        });

        $('#checkAll').on('click', function () {
            $('.student-check').prop('checked', $(this).prop('checked'));
            updateWaCount();
        });
        $(document).on('click', '.student-check', updateWaCount);

        function updateWaCount() {
            $('#waCount').text($('.student-check:checked').length + ' selected');
        }

        $('#waSendBtn').on('click', function () {
            const names = $('.student-check:checked').map(function () {
                return $(this).closest('tr').data('name');
            }).get();
            if (names.length === 0) return;
            $('#waConfirm').show().text('✓ Sent to ' + names.length + ': ' + names.join(', ') + ' — (demo only; connect WhatsApp Business API to send for real)');
        });
    });
</script>
@endpush
