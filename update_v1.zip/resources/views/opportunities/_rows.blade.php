@forelse ($opportunities as $opportunity)
    @php $days = $opportunity->daysLeft(); @endphp
    <div class="board-row">
        <div>
            <div class="board-prog">{{ $opportunity->name }}</div>
            <div class="board-req">{{ $opportunity->requirements }}</div>
            <div class="board-meta">
                <span class="cost-tag">{{ $opportunity->currency }} {{ number_format($opportunity->cost, 0) }}</span>
                @if ($opportunity->official_link)
                    <a href="{{ $opportunity->official_link }}" target="_blank" rel="noopener" class="board-link">Official &#8599;</a>
                @endif
                @if ($opportunity->application_link)
                    <a href="{{ $opportunity->application_link }}" target="_blank" rel="noopener" class="board-link">Apply &#8599;</a>
                @endif
                <span class="board-link download-package"
                      data-name="{{ $opportunity->name }}"
                      data-country="{{ $opportunity->country }}"
                      data-type="{{ $opportunity->type === 'study_abroad' ? 'Study Abroad' : 'Research Publication' }}"
                      data-deadline="{{ $opportunity->deadline->toDateString() }}"
                      data-requirements="{{ $opportunity->requirements }}"
                      data-cost="{{ $opportunity->currency }} {{ number_format($opportunity->cost, 2) }}"
                      data-guidance="{{ $opportunity->guidance }}"
                      data-official="{{ $opportunity->official_link }}"
                      data-application="{{ $opportunity->application_link }}">
                    Download Package &#11015;
                </span>
            </div>
        </div>
        <div>
            <span class="type-tag {{ $opportunity->type === 'study_abroad' ? 'sa' : 'rp' }}">
                {{ $opportunity->type === 'study_abroad' ? 'STUDY' : 'PAPER' }}
            </span>
        </div>
        <div class="board-country">{{ $opportunity->country }}</div>
        <div class="flap">{{ $opportunity->deadline->toDateString() }}</div>
        <div class="countdown {{ $days < 0 ? 'late' : ($days <= 14 ? 'soon' : 'ok') }}">
            {{ $days < 0 ? 'T+'.abs($days).'D LATE' : ($days === 0 ? 'TODAY' : 'T-'.$days.'D') }}
        </div>
    </div>
@empty
    <div class="board-empty">No opportunities match your search.</div>
@endforelse
