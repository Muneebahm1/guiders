<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\FollowUpController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LeadController;
use App\Http\Controllers\OpportunityController;
use App\Http\Controllers\PaperController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\SuggestController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ActivityLogController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login']);
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

Route::get('/register', [RegisterController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [RegisterController::class, 'register']);

Route::get('/home', [HomeController::class, 'index'])->name('home');
Route::get('/home/ping', [HomeController::class, 'ping'])->name('home.ping');

Route::get('/opportunities', [OpportunityController::class, 'index'])->name('opportunities.index');
Route::post('/opportunities', [OpportunityController::class, 'store'])->name('opportunities.store');

Route::get('/leads', [LeadController::class, 'index'])->name('leads.index');
Route::get('/leads/all', [LeadController::class, 'all'])->name('leads.all');
Route::get('/leads/follow-ups', [LeadController::class, 'followUps'])->name('leads.follow-ups');
Route::post('/leads', [LeadController::class, 'store'])->name('leads.store');
Route::patch('/leads/{lead}/cycle-status', [LeadController::class, 'cycleStatus'])->name('leads.cycle-status');
Route::patch('/leads/{lead}/profile', [LeadController::class, 'updateProfile'])->name('leads.update-profile');
Route::post('/leads/{lead}/move-to-followup', [LeadController::class, 'moveToFollowUp'])->name('leads.move-to-followup');
Route::post('/leads/{lead}/convert', [LeadController::class, 'convert'])->name('leads.convert');
Route::delete('/leads/{lead}', [LeadController::class, 'destroy'])->name('leads.destroy');
Route::post('/leads/{lead}/reminders', [LeadController::class, 'storeReminder'])->name('leads.reminders.store');
Route::patch('/reminders/{reminder}/complete', [LeadController::class, 'completeReminder'])->name('reminders.complete');
Route::patch('/reminders/{reminder}/snooze', [LeadController::class, 'snoozeReminder'])->name('reminders.snooze');
Route::delete('/reminders/{reminder}', [LeadController::class, 'destroyReminder'])->name('reminders.destroy');
Route::post('/leads/{lead}/documents', [LeadDocumentController::class, 'store'])->name('leads.documents.store');
Route::delete('/documents/{document}', [LeadDocumentController::class, 'destroy'])->name('documents.destroy');

Route::get('/students', [StudentController::class, 'index'])->name('students.index');
Route::post('/students/register', [StudentController::class, 'registerPartnerStudent'])->name('students.register');
Route::post('/students/{student}/claim', [StudentController::class, 'claim'])->name('students.claim');
Route::patch('/students/{student}/cycle-app-stage', [StudentController::class, 'cycleAppStage'])->name('students.cycle-app-stage');
Route::patch('/students/{student}/cycle-visa-stage', [StudentController::class, 'cycleVisaStage'])->name('students.cycle-visa-stage');

Route::get('/papers', [PaperController::class, 'index'])->name('papers.index');
Route::post('/papers', [PaperController::class, 'store'])->name('papers.store');
Route::patch('/papers/{paper}/cycle-status', [PaperController::class, 'cycleStatus'])->name('papers.cycle-status');

Route::get('/followups', [FollowUpController::class, 'index'])->name('followups.index');
Route::get('/followups/all', [FollowUpController::class, 'all'])->name('followups.all');
Route::post('/followups', [FollowUpController::class, 'store'])->name('followups.store');
Route::patch('/followups/{followUp}/cycle-action', [FollowUpController::class, 'cycleAction'])->name('followups.cycle-action');
Route::post('/followups/upload', [FollowUpController::class, 'upload'])->name('followups.upload');
Route::get('/followups/template', [FollowUpController::class, 'template'])->name('followups.template');

Route::get('/suggest', [SuggestController::class, 'index'])->name('suggest.index');
Route::get('/suggest/search', [SuggestController::class, 'search'])->name('suggest.search');

Route::get('/users', [UserController::class, 'index'])->name('users.index');
Route::post('/users', [UserController::class, 'store'])->name('users.store');
Route::patch('/users/{user}', [UserController::class, 'update'])->name('users.update');
Route::delete('/users/{user}', [UserController::class, 'destroy'])->name('users.destroy');

Route::get('/activity', [ActivityLogController::class, 'index'])->name('activity.index');
