<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;

#[Fillable([
    'user_id', 'counselor_id', 'partner_id', 'opportunity_id', 'name',
    'app_stage', 'fee_date', 'visa_stage', 'visa_date',
])]
class Student extends Model
{
    const APP_STAGES = ['Not Applied', 'Submitted', 'Waiting for Acceptance', 'Accepted', 'Rejected'];

    const VISA_STAGES = ['Not Started', 'Fee Paid', 'Visa Documentation', 'Visa Process', 'Visa Approved', 'Traveling', 'Visa Rejected'];

    protected function casts(): array
    {
        return [
            'fee_date' => 'date',
            'visa_date' => 'date',
        ];
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function counselor()
    {
        return $this->belongsTo(User::class, 'counselor_id');
    }

    public function partner()
    {
        return $this->belongsTo(User::class, 'partner_id');
    }

    public function opportunity()
    {
        return $this->belongsTo(Opportunity::class);
    }

    public function nextAppStage(): string
    {
        $i = array_search($this->app_stage, self::APP_STAGES);

        return self::APP_STAGES[($i + 1) % count(self::APP_STAGES)];
    }

    public function nextVisaStage(): string
    {
        $i = array_search($this->visa_stage, self::VISA_STAGES);

        return self::VISA_STAGES[($i + 1) % count(self::VISA_STAGES)];
    }
}
