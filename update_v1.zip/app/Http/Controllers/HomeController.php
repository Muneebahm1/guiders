<?php

namespace App\Http\Controllers;

use App\Models\FollowUp;
use App\Models\Lead;
use App\Models\Opportunity;
use App\Models\Paper;
use App\Models\Student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $user = Auth::user();

        if ($user->isStudent()) {
            return redirect()->route('students.index');
        }

        if ($user->isPartner()) {
            return redirect()->route('students.index');
        }

        if ($user->hasBackOfficeAccess()) {
            $stats = [
                'Open opportunities' => Opportunity::where('deadline', '>=', now()->startOfDay())->count(),
                'Closing within 14 days' => Opportunity::whereBetween('deadline', [now()->startOfDay(), now()->addDays(14)])->count(),
                'Papers in review' => Paper::whereIn('status', ['Submitted', 'Under Review', 'Revisions Requested'])->count(),
                'Visa cases in progress' => Student::whereNotIn('visa_stage', ['Not Started', 'Visa Approved', 'Visa Rejected'])->count(),
                'Total leads' => Lead::count(),
                'Total follow-ups' => FollowUp::count(),
            ];
            return view('home', compact('stats'));
        }

        // Counselors redirect directly to leads page
        return redirect()->route('leads.index');
    }

    public function ping(Request $request)
    {
        return response()->json([
            'message' => 'pong',
            'user' => Auth::user()->only('id', 'name', 'email'),
            'time' => now()->toDateTimeString(),
        ]);
    }
}
