<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\Opportunity;
use App\Models\Student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class StudentController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $user = Auth::user();

        if ($user->isStudent()) {
            $student = $user->studentProfile()->with(['counselor', 'opportunity'])->first();

            return view('students.show', compact('student'));
        }

        if ($user->isPartner()) {
            $students = Student::where('partner_id', $user->id)->with('opportunity')->latest()->get();
            $opportunities = Opportunity::where('type', 'study_abroad')->orderBy('name')->get();

            return view('students.partner', compact('students', 'opportunities'));
        }

        $students = $user->hasBackOfficeAccess()
            ? Student::with(['counselor', 'partner', 'opportunity'])->latest()->get()
            : Student::where('counselor_id', $user->id)->with('opportunity')->latest()->get();

        $unassigned = $user->hasBackOfficeAccess() || $user->isCounselor()
            ? Student::whereNull('counselor_id')->whereNull('partner_id')->get()
            : collect();

        $opportunities = Opportunity::orderBy('name')->get();

        return view('students.index', compact('students', 'unassigned', 'opportunities'));
    }

    public function claim(Request $request, Student $student)
    {
        if (! Auth::user()->isCounselor() && ! Auth::user()->hasBackOfficeAccess()) {
            abort(403);
        }

        $data = $request->validate([
            'opportunity_id' => ['nullable', 'exists:opportunities,id'],
        ]);

        $student->update([
            'counselor_id' => Auth::id(),
            'opportunity_id' => $data['opportunity_id'] ?? null,
        ]);

        ActivityLog::record('student.claimed', "Claimed student \"{$student->name}\"");

        return redirect()->route('students.index')->with('status', 'Student assigned.');
    }

    public function registerPartnerStudent(Request $request)
    {
        if (! Auth::user()->isPartner()) {
            abort(403);
        }

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'opportunity_id' => ['required', 'exists:opportunities,id'],
        ]);

        Student::create([
            'partner_id' => Auth::id(),
            'opportunity_id' => $data['opportunity_id'],
            'name' => $data['name'],
        ]);

        ActivityLog::record('student.registered', "Registered student \"{$data['name']}\"");

        return redirect()->route('students.index')->with('status', 'Student registered.');
    }

    public function cycleAppStage(Student $student)
    {
        $this->authorizeStudent($student);

        $student->update(['app_stage' => $student->nextAppStage()]);

        ActivityLog::record('student.app_stage_changed', "\"{$student->name}\" application stage moved to {$student->app_stage}");

        return response()->json(['app_stage' => $student->app_stage]);
    }

    public function cycleVisaStage(Student $student)
    {
        $this->authorizeStudent($student);

        $next = $student->nextVisaStage();
        $update = ['visa_stage' => $next];

        if ($next === 'Fee Paid' && ! $student->fee_date) {
            $update['fee_date'] = now();
        }

        if ($next === 'Visa Submitted' && ! $student->visa_date) {
            $update['visa_date'] = now();
        }

        $student->update($update);

        ActivityLog::record('student.visa_stage_changed', "\"{$student->name}\" visa stage moved to {$student->visa_stage}");

        return response()->json([
            'visa_stage' => $student->visa_stage,
            'fee_date' => $student->fee_date?->toDateString(),
            'visa_date' => $student->visa_date?->toDateString(),
        ]);
    }

    private function authorizeStudent(Student $student): void
    {
        $user = Auth::user();

        if ($user->hasBackOfficeAccess()) {
            return;
        }

        if ($student->counselor_id === $user->id) {
            return;
        }

        abort(403);
    }
}
