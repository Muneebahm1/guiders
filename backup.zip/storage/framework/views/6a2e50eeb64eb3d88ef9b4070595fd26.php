<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('subtitle', 'Your pipeline at a glance'); ?>

<?php $__env->startSection('content'); ?>
    <div class="stat-row">
        <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="stat-card">
                <div class="stat-num"><?php echo e($value); ?></div>
                <div class="stat-label"><?php echo e($label); ?></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="panel">
        <div class="panel-head">
            <div><h2>Quick check</h2><p>Confirms the stack (AJAX + Eloquent) is wired end-to-end</p></div>
        </div>
        <div class="p-3">
            <button id="ping-btn" type="button" class="btn btn-sm btn-secondary">
                Ping (AJAX + Eloquent)
            </button>
            <div id="ping-result" class="mt-3"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(function () {
        $('#ping-btn').on('click', function () {
            $.get('<?php echo e(route('home.ping')); ?>', function (data) {
                $('#ping-result').html(
                    '<pre class="bg-light p-2 border rounded">' + JSON.stringify(data, null, 2) + '</pre>'
                );
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\guiders\resources\views/home.blade.php ENDPATH**/ ?>