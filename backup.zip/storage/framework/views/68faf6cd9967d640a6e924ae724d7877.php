<?php $__env->startSection('title', 'Tasks'); ?>
<?php $__env->startSection('subtitle', 'Reminders and to-dos for the team'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row g-3">
        <div class="col-lg-4">
            <div class="panel">
                <div class="panel-head">
                    <div><h2>New Task</h2><p>&nbsp;</p></div>
                </div>
                <form method="POST" action="<?php echo e(route('tasks.store')); ?>" class="p-3">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Title</label>
                        <input class="form-control" name="title" required placeholder="e.g. Follow up on Hamza's visa docs">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Notes (optional)</label>
                        <textarea class="form-control" name="notes" rows="2" placeholder="Any extra detail..."></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Assign to</label>
                        <select class="form-select" name="assigned_to_id" required>
                            <?php $__currentLoopData = $assignees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($assignee->id); ?>" <?php echo e($assignee->id === auth()->id() ? 'selected' : ''); ?>><?php echo e($assignee->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label">Due date</label>
                            <input class="form-control" type="date" name="due_date">
                        </div>
                        <div class="col-6">
                            <label class="form-label">Due time</label>
                            <input class="form-control" type="time" name="due_time">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Priority</label>
                        <select class="form-select" name="priority">
                            <option value="low">Low</option>
                            <option value="medium" selected>Medium</option>
                            <option value="high">High</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Create task</button>
                </form>
            </div>
        </div>

        <div class="col-lg-8">
            <div class="panel">
                <div class="panel-head">
                    <div class="btn-group">
                        <a href="<?php echo e(route('tasks.index', ['filter' => 'mine'])); ?>" class="btn btn-sm <?php echo e($filter === 'mine' ? 'btn-primary' : 'btn-outline-secondary'); ?>">Assigned to me</a>
                        <a href="<?php echo e(route('tasks.index', ['filter' => 'created'])); ?>" class="btn btn-sm <?php echo e($filter === 'created' ? 'btn-primary' : 'btn-outline-secondary'); ?>">Created by me</a>
                        <?php if(auth()->user()->hasBackOfficeAccess()): ?>
                            <a href="<?php echo e(route('tasks.index', ['filter' => 'all'])); ?>" class="btn btn-sm <?php echo e($filter === 'all' ? 'btn-primary' : 'btn-outline-secondary'); ?>">Everyone's</a>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="p-3">
                    <?php if($tasks->isEmpty()): ?>
                        <div class="empty-state">No tasks here yet.</div>
                    <?php else: ?>
                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex justify-content-between align-items-start gap-3 py-3 <?php echo e(!$loop->first ? 'border-top' : ''); ?>">
                                <div>
                                    <div class="<?php echo e($task->done ? 'text-decoration-line-through text-muted' : ''); ?> fw-semibold"><?php echo e($task->title); ?></div>
                                    <?php if($task->notes): ?>
                                        <div class="text-muted small mt-1"><?php echo e($task->notes); ?></div>
                                    <?php endif; ?>
                                    <div class="d-flex gap-2 align-items-center mt-2 flex-wrap">
                                        <span class="badge <?php echo e(!$task->done && $task->isOverdue() ? 'bg-danger' : 'bg-secondary-subtle text-dark'); ?>">
                                            <?php echo e(!$task->done && $task->isOverdue() ? 'Overdue' : 'Due'); ?>

                                            <?php echo e($task->due_date ? '· '.$task->due_date->format('M j, Y').($task->due_time ? ' '.\Illuminate\Support\Carbon::parse($task->due_time)->format('g:i A') : '') : '· No due date'); ?>

                                        </span>
                                        <span class="badge bg-light text-dark border text-uppercase"><?php echo e($task->priority); ?></span>
                                        <span class="text-muted small">Assigned to <strong><?php echo e($task->assignee->name); ?></strong> &middot; by <?php echo e($task->creator->name ?? '—'); ?></span>
                                    </div>
                                </div>
                                <div class="d-flex gap-2 flex-shrink-0">
                                    <form method="POST" action="<?php echo e(route('tasks.complete', $task)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-secondary" title="<?php echo e($task->done ? 'Mark as not done' : 'Mark as done'); ?>"><?php echo e($task->done ? 'Reopen' : 'Done'); ?></button>
                                    </form>
                                    <?php if(auth()->user()->hasBackOfficeAccess() || $task->created_by_id === auth()->id()): ?>
                                        <form method="POST" action="<?php echo e(route('tasks.destroy', $task)); ?>" onsubmit="return confirm('Delete this task?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u943754902/domains/deekod.com/public_html/guiders/resources/views/tasks/index.blade.php ENDPATH**/ ?>