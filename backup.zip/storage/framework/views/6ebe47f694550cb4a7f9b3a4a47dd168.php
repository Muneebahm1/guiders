<?php $__env->startSection('title', 'My Progress'); ?>
<?php $__env->startSection('subtitle', 'Where your case stands right now'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(! $student): ?>
        <p class="text-muted">No student profile found.</p>
    <?php else: ?>
        <div class="readonly-banner">
            This is read-only. Your counselor updates each stage as your case moves forward &mdash; reach out to them with questions.
        </div>

        <div class="panel">
            <div class="panel-head">
                <div>
                    <h2>Study Abroad &mdash; <?php echo e($student->opportunity->name ?? 'No program assigned yet'); ?></h2>
                    <p>Counselor: <?php echo e($student->counselor->name ?? 'Not yet assigned'); ?></p>
                </div>
            </div>

            <?php
                $steps = [
                    ['label' => 'Application Submitted'],
                    ['label' => 'Waiting for Acceptance'],
                    ['label' => 'Accepted'],
                    ['label' => 'Fee Paid', 'date' => $student->fee_date?->toDateString()],
                    ['label' => 'Visa Documentation'],
                    ['label' => 'Visa Process', 'date' => $student->visa_date?->toDateString()],
                    ['label' => 'Visa Approved'],
                    ['label' => 'Traveling'],
                ];

                $currentIndex = match(true) {
                    $student->app_stage === 'Not Applied' => -1,
                    $student->app_stage === 'Submitted' => 0,
                    $student->app_stage === 'Waiting for Acceptance' => 1,
                    $student->app_stage === 'Rejected' => 0,
                    default => match($student->visa_stage) {
                        'Not Started' => 2,
                        'Fee Paid' => 3,
                        'Visa Documentation' => 4,
                        'Visa Process' => 5,
                        'Visa Approved' => 6,
                        'Traveling' => 7,
                        'Visa Rejected' => 5,
                        default => 2,
                    },
                };

                $rejected = $student->app_stage === 'Rejected' ? 1 : ($student->visa_stage === 'Visa Rejected' ? 6 : -1);
            ?>

            <div class="timeline">
                <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $state = $rejected === $i ? 'rejected' : ($i < $currentIndex ? 'done' : ($i === $currentIndex ? 'current' : ''));
                    ?>
                    <div class="tl-step <?php echo e($state); ?>">
                        <div class="tl-line"></div>
                        <div class="tl-dot"><?php echo e($state === 'done' ? '✓' : ($state === 'rejected' ? '✕' : $i + 1)); ?></div>
                        <div class="tl-body">
                            <div class="tl-title"><?php echo e($step['label']); ?></div>
                            <?php if(!empty($step['date'])): ?>
                                <div class="tl-date"><?php echo e($step['date']); ?></div>
                            <?php endif; ?>
                            <?php if($state === 'current'): ?>
                                <div class="tl-note">In progress</div>
                            <?php endif; ?>
                            <?php if($state === 'rejected'): ?>
                                <div class="tl-note">Not moving forward at this stage</div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\guiders\resources\views/students/show.blade.php ENDPATH**/ ?>