<?php
    $editable = $editable ?? false;

    $steps = [
        ['label' => 'Application Submitted'],
        ['label' => 'Waiting for Acceptance'],
        ['label' => 'Accepted'],
        ['label' => 'Fee — '.$application->fee_status, 'date' => $application->fee_date?->toDateString()],
        ['label' => 'Visa Documentation'],
        ['label' => 'Visa Submitted', 'date' => $application->visa_submission_date?->toDateString()],
        ['label' => 'Visa Approved'],
        ['label' => $application->travel_status === 'Travelled' ? 'Travelled' : 'Cleared to Travel', 'date' => $application->travel_date?->toDateString()],
    ];

    $currentIndex = match(true) {
        $application->app_stage === 'Not Applied' => -1,
        $application->app_stage === 'Submitted' => 0,
        $application->app_stage === 'Waiting for Acceptance' => 1,
        $application->app_stage === 'Rejected' => 0,
        $application->fee_status !== 'Paid' => 3,
        $application->visa_stage === 'Not Started' => 4,
        $application->visa_stage === 'Documentation' => 4,
        $application->visa_stage === 'Submitted' => 5,
        $application->visa_stage === 'Rejected' => 5,
        $application->visa_stage === 'Approved' && $application->travel_status === 'Not Ready' => 6,
        default => 7,
    };

    $rejected = $application->app_stage === 'Rejected' ? 1 : ($application->visa_stage === 'Rejected' ? 5 : -1);
?>

<div class="panel application-panel" data-application-id="<?php echo e($application->id); ?>">
    <div class="panel-head">
        <div>
            <h2><?php echo e($application->opportunity->name ?? 'No program assigned yet'); ?></h2>
            <p>
                <?php if($application->opportunity): ?>
                    <?php echo e($application->opportunity->country); ?> &middot;
                <?php endif; ?>
                Fee: <?php echo e($application->fee_status); ?> &middot; Visa: <?php echo e($application->visa_stage); ?> &middot; Travel: <?php echo e($application->travel_status); ?>

            </p>
        </div>
        <?php if($editable): ?>
            <div class="d-flex gap-2 flex-wrap">
                <span class="chip app-stage-chip <?php echo e(match($application->app_stage) { 'Accepted' => 'teal', 'Rejected' => 'coral', 'Not Applied' => 'gray', default => 'amber' }); ?>"
                      data-url="<?php echo e(route('applications.cycle-app-stage', $application)); ?>"><?php echo e($application->app_stage); ?></span>
                <span class="chip visa-stage-chip <?php echo e(match($application->visa_stage) { 'Approved' => 'teal', 'Rejected' => 'coral', 'Not Started' => 'gray', default => 'amber' }); ?>"
                      data-url="<?php echo e(route('applications.cycle-visa-stage', $application)); ?>"><?php echo e($application->visa_stage); ?></span>
                <span class="chip travel-status-chip <?php echo e(match($application->travel_status) { 'Travelled' => 'teal', 'Cleared to Travel' => 'gold', default => 'gray' }); ?>"
                      data-url="<?php echo e(route('applications.cycle-travel-status', $application)); ?>"><?php echo e($application->travel_status); ?></span>
                <a href="<?php echo e(route('clearance.show', $application)); ?>" class="chip static gray">Clearance report</a>
                <form method="POST" action="<?php echo e(route('applications.destroy', $application)); ?>" onsubmit="return confirm('Remove this application?');">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="chip static coral" style="border:none;">Remove</button>
                </form>
            </div>
        <?php endif; ?>
    </div>

    <div class="timeline">
        <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $state = $rejected === $i ? 'rejected' : ($i < $currentIndex ? 'done' : ($i === $currentIndex ? 'current' : ''));
            ?>
            <div class="tl-step <?php echo e($state); ?>">
                <div class="tl-line"></div>
                <div class="tl-dot"><?php echo e($state === 'done' ? '✓' : ($state === 'rejected' ? '✕' : $i + 1)); ?></div>
                <div class="tl-body">
                    <div class="tl-title"><?php echo e($step['label']); ?></div>
                    <?php if(!empty($step['date'])): ?>
                        <div class="tl-date"><?php echo e($step['date']); ?></div>
                    <?php endif; ?>
                    <?php if($state === 'current'): ?>
                        <div class="tl-note">In progress</div>
                    <?php endif; ?>
                    <?php if($state === 'rejected'): ?>
                        <div class="tl-note">Not moving forward at this stage</div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php if($application->installments->isNotEmpty()): ?>
        <div class="table-responsive">
            <table class="table table-sm mb-0">
                <thead><tr><th>Installment</th><th>Amount</th><th>Due</th><th>Paid</th><?php if($editable): ?><th></th><?php endif; ?></tr></thead>
                <tbody>
                    <?php $__currentLoopData = $application->installments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $installment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($installment->title); ?></td>
                            <td><?php echo e($installment->currency); ?> <?php echo e(number_format($installment->amount, 2)); ?></td>
                            <td class="<?php echo e(! $installment->paid_date && $installment->due_date->isPast() ? 'text-danger fw-bold' : ''); ?>"><?php echo e($installment->due_date->toDateString()); ?></td>
                            <td><?php echo e($installment->paid_date?->toDateString() ?? '—'); ?></td>
                            <?php if($editable): ?>
                                <td>
                                    <?php if(! $installment->paid_date): ?>
                                        <form method="POST" action="<?php echo e(route('installments.mark-paid', $installment)); ?>">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-primary">Mark paid</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    <?php if($editable): ?>
        <form method="POST" action="<?php echo e(route('installments.store', $application)); ?>" class="form-row p-3 border-top">
            <?php echo csrf_field(); ?>
            <input class="form-control" name="title" placeholder="Installment title" required>
            <input class="form-control" name="amount" type="number" step="0.01" min="0" placeholder="Amount" required>
            <input class="form-control" name="currency" placeholder="Currency" value="USD" style="max-width:100px" required>
            <input class="form-control" name="due_date" type="date" required>
            <button class="btn btn-outline-primary" type="submit">+ Add Installment</button>
        </form>
    <?php endif; ?>
</div>
<?php /**PATH /home/u943754902/domains/deekod.com/public_html/guiders/resources/views/students/_application_timeline.blade.php ENDPATH**/ ?>