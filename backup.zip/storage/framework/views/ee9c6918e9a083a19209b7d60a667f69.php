<?php $__env->startSection('title', 'All Leads'); ?>
<?php $__env->startSection('subtitle', 'Every lead across all counselors — read-only'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel">
        <div class="panel-head">
            <div><h2>Leads</h2><p><?php echo e($leads->count()); ?> total</p></div>
        </div>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Counselor</th>
                        <th>Contact number</th>
                        <th>Source</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="name-cell"><?php echo e($lead->name); ?></td>
                            <td><?php echo e($lead->counselor->name ?? '—'); ?></td>
                            <td><?php echo e($lead->contact ?: '—'); ?></td>
                            <td><?php echo e($lead->source); ?></td>
                            <td>
                                <span class="chip static <?php echo e(match($lead->status) {
                                    'Registered' => 'teal',
                                    'Visit' => 'gold',
                                    'New' => 'gray',
                                    default => 'amber',
                                }); ?>"><?php echo e($lead->status); ?></span>
                            </td>
                            <td>
                                <?php if($lead->hasProfile()): ?>
                                    <button type="button" class="btn btn-outline-primary btn-sm" data-bs-toggle="collapse" data-bs-target="#leadProfile<?php echo e($lead->id); ?>">
                                        View profile
                                    </button>
                                <?php else: ?>
                                    <span class="sub-cell">No profile yet</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php if($lead->hasProfile()): ?>
                            <tr class="collapse" id="leadProfile<?php echo e($lead->id); ?>">
                                <td colspan="6" class="p-3" style="background:#FAFBFD">
                                    <div class="row g-2 small">
                                        <div class="col-md-3"><strong>Desired program:</strong> <?php echo e($lead->desired_program ?: '—'); ?></div>
                                        <div class="col-md-3"><strong>Country:</strong> <?php echo e($lead->country ?: '—'); ?></div>
                                        <div class="col-md-3"><strong>Budget:</strong> <?php echo e($lead->budget ? 'USD '.$lead->budget : '—'); ?></div>
                                        <div class="col-md-3"><strong>City:</strong> <?php echo e($lead->city ?: '—'); ?></div>
                                        <div class="col-md-3"><strong>Last qualification:</strong> <?php echo e($lead->last_qualification ?: '—'); ?></div>
                                        <div class="col-md-3"><strong>CGPA:</strong> <?php echo e($lead->cgpa ?: '—'); ?></div>
                                        <div class="col-md-3"><strong>Age:</strong> <?php echo e($lead->age ?: '—'); ?></div>
                                    </div>
                                    <?php if($lead->suggestion): ?>
                                        <div class="mt-2 small"><strong>Suggestion:</strong> <?php echo e($lead->suggestion); ?></div>
                                    <?php endif; ?>
                                    <?php if($lead->remarks): ?>
                                        <div class="mt-1 small"><strong>Remarks:</strong> <?php echo e($lead->remarks); ?></div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6" class="empty-state">No leads yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u943754902/domains/deekod.com/public_html/guiders/resources/views/leads/all.blade.php ENDPATH**/ ?>