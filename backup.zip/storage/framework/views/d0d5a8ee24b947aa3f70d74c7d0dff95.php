<?php $__env->startSection('content'); ?>
<div class="auth-wrap">
    <div class="auth-card text-center">
        <img src="<?php echo e(asset('img/logo/logoguidr.png')); ?>" alt="The Guiders" class="auth-logo">
        <h1><?php echo e(config('app.name', 'The Guiders')); ?></h1>
        <p class="text-muted mb-4">Study abroad and research-publication guidance, from lead to visa approval.</p>

        <?php if(auth()->guard()->guest()): ?>
            <a href="<?php echo e(route('login')); ?>" class="btn btn-primary w-100">Login</a>
            <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-primary w-100 mt-2">Register</a>
        <?php else: ?>
            <a href="<?php echo e(route('home')); ?>" class="btn btn-primary w-100">Go to Dashboard</a>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u943754902/domains/deekod.com/public_html/guiders/resources/views/welcome.blade.php ENDPATH**/ ?>