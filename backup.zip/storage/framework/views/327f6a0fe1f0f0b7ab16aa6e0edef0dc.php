<?php $__env->startSection('title', 'Follow-ups'); ?>
<?php $__env->startSection('subtitle', 'Your own tracking sheet, turned into call/visit reminders'); ?>

<?php $__env->startSection('content'); ?>
    <div class="stat-row">
        <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="stat-card">
                <div class="stat-num"><?php echo e($value); ?></div>
                <div class="stat-label"><?php echo e($label); ?></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="panel">
        <div class="panel-head">
            <div><h2>Bulk Import (optional)</h2><p>Upload a legacy tracking sheet — rows match to existing leads by name, or create new ones</p></div>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-toggle="collapse" data-bs-target="#emailComposer">
                    📧 Email New Opportunity
                </button>
                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="collapse" data-bs-target="#addLeadForm">
                    + Add Lead
                </button>
            </div>
        </div>

        <div class="collapse" id="emailComposer">
            <div class="p-3 border-bottom" style="background:#F0FBF7">
                <div class="mb-2">
                    <label style="font-size:11px;color:var(--muted);">New opportunity:</label>
                    <select id="emailOpp" class="form-select" style="padding:6px 10px;border:1px solid var(--line);border-radius:6px;font-size:12px;"></select>
                </div>
                <input id="emailSubject" class="form-control mb-2" placeholder="Subject" style="width:100%;padding:8px 10px;border:1px solid var(--line);border-radius:6px;font-size:12.5px;">
                <textarea id="emailBody" class="form-control mb-2" rows="3">Hi {name}, we wanted to let you know about a new opportunity that might interest you...</textarea>
                <div class="d-flex gap-2 align-items-center flex-wrap">
                    <button id="emailSendBtn" class="btn btn-sm btn-primary" type="button">Send Email to Selected</button>
                    <span id="emailCount" class="text-muted small">0 selected</span>
                </div>
                <div id="emailConfirm" class="small text-success mt-2" style="display:none"></div>
            </div>
        </div>

        <div class="collapse" id="addLeadForm">
            <form method="POST" action="<?php echo e(route('leads.store')); ?>" class="form-row">
                <?php echo csrf_field(); ?>
                <input class="form-control" name="name" placeholder="Full name" required>
                <input class="form-control" name="contact" placeholder="Phone or email">
                <select class="form-select" name="source">
                    <?php $__currentLoopData = \App\Models\Lead::SOURCES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($source); ?>"><?php echo e($source); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button class="btn btn-primary" type="submit">Save</button>
            </form>
        </div>

        <div class="upload-row">
            <input type="file" id="followupFile" accept=".xlsx,.xls,.csv">
            <button type="button" class="btn btn-outline-secondary btn-sm" onclick="downloadTemplate()">Download blank template</button>
        </div>
        <div id="importSummary" class="empty-state">No sheet imported yet — or just work with leads below directly.</div>
    </div>

    <div id="followupCards">
        <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="fu-card">
                <div class="fu-head">
                    <div class="fu-name">
                        <input type="checkbox" class="followup-check" value="<?php echo e($lead->id); ?>" onclick="updateEmailCount()" style="margin-right:4px;">
                        <button class="star-btn <?php echo e($lead->highly_interested ?? false ? 'on' : 'off'); ?>" onclick="toggleInterested(<?php echo e($lead->id); ?>)" title="Mark highly interested">⭐</button>
                        <?php echo e($lead->name); ?>

                        <?php if($lead->highly_interested ?? false): ?>
                            <span class="highly-interested-tag">HOT LEAD</span>
                        <?php endif; ?>
                        <span style="font-size:11px;color:var(--muted);font-weight:400;">— <?php echo e($lead->source); ?></span>
                    </div>
                    <div class="d-flex gap-1 flex-wrap">
                        <span class="chip status-chip
                            <?php echo e(match($lead->status) {
                                'Registered' => 'teal',
                                'Visit' => 'gold',
                                'New' => 'gray',
                                default => 'amber',
                            }); ?>" data-cycle-url="<?php echo e(route('leads.cycle-status', $lead)); ?>">
                            <?php echo e($lead->status); ?>

                        </span>
                        <button class="btn btn-outline-secondary btn-sm" onclick="logCall(<?php echo e($lead->id); ?>)">📞 Log Call</button>
                        <button class="btn btn-outline-secondary btn-sm" onclick="logActivity(<?php echo e($lead->id); ?>, 'visits')">📍 Log Visit</button>
                    </div>
                </div>
                <div class="fu-body">
                    <div style="margin-bottom:12px;"><?php echo $lead->getCallSequenceHtml(); ?></div>

                    <div style="margin-bottom:12px;padding:12px;background:#FAFBFD;border-radius:8px;">
                        <label style="font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:0.05em;display:block;margin-bottom:5px;">ACTIVITY TIMELINE</label>
                        <?php
                            $activities = collect();
                            // Add call logs
                            foreach($lead->callLogs as $call) {
                                $activities->push([
                                    'type' => 'call',
                                    'date' => $call->call_date,
                                    'icon' => '📞',
                                    'title' => 'Call logged',
                                    'details' => $call->outcome . ($call->duration_seconds ? ' (' . $call->duration_seconds . 's)' : ''),
                                    'notes' => $call->notes
                                ]);
                            }
                            // Add communications
                            foreach($lead->communications as $comm) {
                                $activities->push([
                                    'type' => $comm->type,
                                    'date' => $comm->sent_at,
                                    'icon' => $comm->type === 'whatsapp' ? '💬' : ($comm->type === 'email' ? '📧' : '📞'),
                                    'title' => ucfirst($comm->type) . ' ' . ucfirst($comm->direction),
                                    'details' => ucfirst($comm->status),
                                    'notes' => $comm->content
                                ]);
                            }
                            // Add documents
                            foreach($lead->documents as $doc) {
                                $activities->push([
                                    'type' => 'document',
                                    'date' => $doc->created_at,
                                    'icon' => '📎',
                                    'title' => 'Document uploaded',
                                    'details' => $doc->document_type . ' - ' . $doc->file_name,
                                    'notes' => $doc->notes
                                ]);
                            }
                            $activities = $activities->sortByDesc('date');
                        ?>
                        <?php if($activities->count() > 0): ?>
                            <div style="display:flex;flex-direction:column;gap:8px;max-height:200px;overflow-y:auto;">
                                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div style="padding:8px;background:white;border:1px solid var(--line);border-radius:6px;font-size:12px;">
                                        <div style="display:flex;justify-content:space-between;align-items:center;">
                                            <div style="font-weight:600;color:var(--primary);">
                                                <?php echo e($activity['icon']); ?> <?php echo e($activity['title']); ?>

                                            </div>
                                            <span style="font-size:10px;color:var(--muted);"><?php echo e($activity['date']->format('M d, H:i')); ?></span>
                                        </div>
                                        <div style="color:var(--muted);margin-top:2px;"><?php echo e($activity['details']); ?></div>
                                        <?php if($activity['notes']): ?>
                                            <div style="margin-top:4px;font-size:11px;color:var(--muted);font-style:italic;"><?php echo e($activity['notes']); ?></div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <div style="font-size:12px;color:var(--muted);">No activity recorded yet.</div>
                        <?php endif; ?>
                    </div>

                    
                    <div class="profile-grid">
                        <div>
                            <label>AGE</label>
                            <input type="number" value="<?php echo e($lead->age ?? ''); ?>" onchange="updateProfile(<?php echo e($lead->id); ?>, 'age', this.value)">
                        </div>
                        <div>
                            <label>CITY</label>
                            <input type="text" value="<?php echo e($lead->city ?? ''); ?>" onchange="updateProfile(<?php echo e($lead->id); ?>, 'city', this.value)">
                        </div>
                        <div>
                            <label>LAST QUALIFICATION</label>
                            <input type="text" value="<?php echo e($lead->last_qualification ?? ''); ?>" onchange="updateProfile(<?php echo e($lead->id); ?>, 'last_qualification', this.value)">
                        </div>
                        <div>
                            <label>CGPA / MARKS %</label>
                            <input type="text" value="<?php echo e($lead->cgpa ?? ''); ?>" onchange="updateProfile(<?php echo e($lead->id); ?>, 'cgpa', this.value)">
                        </div>
                        <div>
                            <label>ENGLISH TEST</label>
                            <select onchange="updateProfile(<?php echo e($lead->id); ?>, 'english_test', this.value)">
                                <option <?php echo e(($lead->english_test ?? 'None') === 'None' ? 'selected' : ''); ?>>None</option>
                                <option <?php echo e(($lead->english_test ?? 'None') === 'IELTS' ? 'selected' : ''); ?>>IELTS</option>
                                <option <?php echo e(($lead->english_test ?? 'None') === 'TOEFL' ? 'selected' : ''); ?>>TOEFL</option>
                                <option <?php echo e(($lead->english_test ?? 'None') === 'PTE' ? 'selected' : ''); ?>>PTE</option>
                                <option <?php echo e(($lead->english_test ?? 'None') === 'Duolingo' ? 'selected' : ''); ?>>Duolingo</option>
                            </select>
                        </div>
                        <div>
                            <label>ENGLISH SCORE</label>
                            <input type="text" value="<?php echo e($lead->english_score ?? ''); ?>" onchange="updateProfile(<?php echo e($lead->id); ?>, 'english_score', this.value)">
                        </div>
                        <div>
                            <label>DESIRED PROGRAM</label>
                            <input type="text" value="<?php echo e($lead->desired_program ?? ''); ?>" onchange="updateProfile(<?php echo e($lead->id); ?>, 'desired_program', this.value)">
                        </div>
                        <div>
                            <label>BUDGET</label>
                            <input type="number" value="<?php echo e($lead->budget ?? ''); ?>" onchange="updateProfile(<?php echo e($lead->id); ?>, 'budget', this.value)">
                        </div>
                        <div>
                            <label>DESIRED COUNTRY</label>
                            <input type="text" value="<?php echo e($lead->country ?? ''); ?>" onchange="updateProfile(<?php echo e($lead->id); ?>, 'country', this.value)">
                        </div>
                        <div>
                            <label>CURRENCY</label>
                            <select onchange="updateProfile(<?php echo e($lead->id); ?>, 'currency', this.value)">
                                <option <?php echo e(($lead->currency ?? 'USD') === 'USD' ? 'selected' : ''); ?>>USD</option>
                                <option <?php echo e(($lead->currency ?? 'USD') === 'EUR' ? 'selected' : ''); ?>>EUR</option>
                                <option <?php echo e(($lead->currency ?? 'USD') === 'GBP' ? 'selected' : ''); ?>>GBP</option>
                                <option <?php echo e(($lead->currency ?? 'USD') === 'PKR' ? 'selected' : ''); ?>>PKR</option>
                            </select>
                        </div>
                    </div>

                    <div style="margin-bottom:12px;padding:12px;background:#FAFBFD;border-radius:8px;">
                        <label style="font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:0.05em;display:block;margin-bottom:5px;">MATCHING OPPORTUNITIES</label>
                        <?php $matchingOpps = $lead->getMatchingOpportunities(); ?>
                        <?php if($matchingOpps->count() > 0): ?>
                            <div style="display:flex;flex-direction:column;gap:8px;">
                                <?php $__currentLoopData = $matchingOpps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div style="padding:8px;background:white;border:1px solid var(--line);border-radius:6px;font-size:12px;">
                                        <div style="display:flex;justify-content:space-between;align-items:center;">
                                            <div style="font-weight:600;color:var(--primary);"><?php echo e($opp->name); ?></div>
                                            <span class="chip <?php echo e($opp->match_score >= 70 ? 'teal' : ($opp->match_score >= 40 ? 'amber' : 'gray')); ?>" style="font-size:10px;"><?php echo e($opp->match_score); ?>% Match</span>
                                        </div>
                                        <div style="color:var(--muted);margin-top:2px;"><?php echo e($opp->country); ?> · <?php echo e($opp->type); ?></div>
                                        <?php if($opp->cost): ?>
                                            <div style="color:var(--gold-dark);margin-top:2px;"><?php echo e($opp->currency ?? 'USD'); ?> <?php echo e(number_format($opp->cost, 2)); ?></div>
                                        <?php endif; ?>
                                        <div style="margin-top:4px;font-size:10px;color:var(--muted);">
                                            <?php echo e(implode(', ', $opp->match_reasons)); ?>

                                        </div>
                                        <div style="margin-top:4px;">
                                            <a href="<?php echo e($opp->official_link); ?>" target="_blank" style="color:var(--primary);font-size:11px;">View Details →</a>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <div style="font-size:12px;color:var(--muted);">No matches — try widening budget or program/country above.</div>
                        <?php endif; ?>
                    </div>

                    <div style="margin-bottom:12px;">
                        <label style="font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:0.05em;display:block;margin-bottom:5px;">REMARKS (VISIT, REGISTRATION, NOTES)</label>
                        <textarea onchange="updateProfile(<?php echo e($lead->id); ?>, 'remarks', this.value)" placeholder="Visit notes, registration details..." style="width:100%;min-height:56px;padding:8px 10px;border:1px solid var(--line);border-radius:6px;font-size:12.5px;"><?php echo e($lead->remarks ?? ''); ?></textarea>
                    </div>

                    <div style="margin-bottom:12px;padding:12px;background:#FAFBFD;border-radius:8px;">
                        <label style="font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:0.05em;display:block;margin-bottom:5px;">DOCUMENTS</label>
                        <div class="document-upload">
                            <select id="docType-<?php echo e($lead->id); ?>" style="padding:6px 10px;border:1px solid var(--line);border-radius:6px;font-size:12px;margin-right:8px;">
                                <?php $__currentLoopData = \App\Models\LeadDocument::DOCUMENT_TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type); ?>"><?php echo e($type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input type="file" id="docFile-<?php echo e($lead->id); ?>" style="display:none;" onchange="uploadDocument(<?php echo e($lead->id); ?>)">
                            <button class="btn btn-outline-secondary btn-sm" onclick="document.getElementById('docFile-<?php echo e($lead->id); ?>').click()">📎 Upload Document</button>
                        </div>
                        <div id="docList-<?php echo e($lead->id); ?>" class="document-list">
                            <?php $__currentLoopData = $lead->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="document-item">
                                    <span class="doc-type"><?php echo e($doc->document_type); ?></span>
                                    <a href="<?php echo e(asset('storage/' . $doc->file_path)); ?>" target="_blank" class="doc-name"><?php echo e($doc->file_name); ?></a>
                                    <button class="btn btn-outline-danger btn-sm" onclick="deleteDocument(<?php echo e($doc->id); ?>)">✕</button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;margin-top:14px;padding-top:14px;border-top:1px solid var(--line);flex-wrap:wrap;">
                        <div style="display:flex;gap:8px;flex-wrap:wrap;">
                            <button class="chip <?php echo e($lead->contract_signed ?? false ? 'teal' : 'gray'); ?>" onclick="toggleContract(<?php echo e($lead->id); ?>)">
                                <?php echo e($lead->contract_signed ?? false ? '✓ Contract Signed ' . ($lead->contract_date ?? '') : '☐ Contract Signed'); ?>

                            </button>
                            <button class="chip <?php echo e($lead->payment_done ?? false ? 'teal' : 'gray'); ?>" onclick="togglePayment(<?php echo e($lead->id); ?>)">
                                <?php echo e($lead->payment_done ?? false ? '✓ Initial Payment ' . ($lead->payment_date ?? '') : '☐ Initial Payment'); ?>

                            </button>
                        </div>
                        <?php $readyToConvert = ($lead->contract_signed ?? false) && ($lead->payment_done ?? false); ?>
                        <button class="btn <?php echo e($readyToConvert ? '' : 'btn-outline-secondary'); ?>" <?php echo e($readyToConvert ? '' : 'disabled style="opacity:0.5;cursor:not-allowed;"'); ?>

                            onclick="<?php echo e($readyToConvert ? "convertToStudent({$lead->id})" : ''); ?>">
                            <?php echo e($readyToConvert ? 'Convert to Registered Student →' : 'Awaiting contract + payment'); ?>

                        </button>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty-state">No one in Follow-ups yet — move a hot lead here from My Leads.</div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    const FOLLOWUP_GAP_DAYS = 3;
    const TODAY = '<?php echo e(now()->format('Y-m-d')); ?>';

    function daysBetween(a, b) {
        return Math.round((new Date(b + 'T00:00:00') - new Date(a + 'T00:00:00')) / 86400000);
    }

    function toggleInterested(leadId) {
        $.ajax({
            url: '<?php echo e(route('leads.update-profile', ['lead' => '__LEAD_ID__'])); ?>'.replace('__LEAD_ID__', leadId),
            method: 'PATCH',
            data: { highly_interested: true },
            success: function () {
                location.reload();
            }
        });
    }

    function logCall(leadId) {
        $.ajax({
            url: '<?php echo e(route('leads.update-profile', ['lead' => '__LEAD_ID__'])); ?>'.replace('__LEAD_ID__', leadId),
            method: 'PATCH',
            data: { log_call: true },
            success: function () {
                location.reload();
            }
        });
    }

    function logActivity(leadId, kind) {
        $.ajax({
            url: '<?php echo e(route('leads.update-profile', ['lead' => '__LEAD_ID__'])); ?>'.replace('__LEAD_ID__', leadId),
            method: 'PATCH',
            data: { log_activity: kind },
            success: function () {
                location.reload();
            }
        });
    }

    function updateProfile(leadId, field, value) {
        $.ajax({
            url: '<?php echo e(route('leads.update-profile', ['lead' => '__LEAD_ID__'])); ?>'.replace('__LEAD_ID__', leadId),
            method: 'PATCH',
            data: { [field]: value },
            success: function () {
                // Profile saved
            }
        });
    }

    function toggleContract(leadId) {
        $.ajax({
            url: '<?php echo e(route('leads.update-profile', ['lead' => '__LEAD_ID__'])); ?>'.replace('__LEAD_ID__', leadId),
            method: 'PATCH',
            data: { toggle_contract: true },
            success: function () {
                location.reload();
            }
        });
    }

    function togglePayment(leadId) {
        $.ajax({
            url: '<?php echo e(route('leads.update-profile', ['lead' => '__LEAD_ID__'])); ?>'.replace('__LEAD_ID__', leadId),
            method: 'PATCH',
            data: { toggle_payment: true },
            success: function () {
                location.reload();
            }
        });
    }

    function convertToStudent(leadId) {
        $.post('<?php echo e(route('leads.convert', ['lead' => '__LEAD_ID__'])); ?>'.replace('__LEAD_ID__', leadId), {}, function () {
            location.reload();
        });
    }

    function uploadDocument(leadId) {
        const fileInput = document.getElementById('docFile-' + leadId);
        const docType = document.getElementById('docType-' + leadId).value;
        const file = fileInput.files[0];

        if (!file) return;

        const formData = new FormData();
        formData.append('file', file);
        formData.append('document_type', docType);
        formData.append('_token', '<?php echo e(csrf_token()); ?>');

        $.ajax({
            url: '<?php echo e(route('leads.documents.store', ['lead' => '__LEAD_ID__'])); ?>'.replace('__LEAD_ID__', leadId),
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function (data) {
                const docList = document.getElementById('docList-' + leadId);
                const docItem = document.createElement('div');
                docItem.className = 'document-item';
                docItem.innerHTML = `
                    <span class="doc-type">${docType}</span>
                    <a href="${data.url}" target="_blank" class="doc-name">${file.name}</a>
                    <button class="btn btn-outline-danger btn-sm" onclick="deleteDocument(${data.document.id})">✕</button>
                `;
                docList.appendChild(docItem);
                fileInput.value = '';
            },
            error: function () {
                alert('Failed to upload document');
            }
        });
    }

    function deleteDocument(docId) {
        if (!confirm('Are you sure you want to delete this document?')) return;

        $.ajax({
            url: '<?php echo e(route('documents.destroy', ['document' => '__DOC_ID__'])); ?>'.replace('__DOC_ID__', docId),
            method: 'DELETE',
            data: { _token: '<?php echo e(csrf_token()); ?>' },
            success: function () {
                location.reload();
            },
            error: function () {
                alert('Failed to delete document');
            }
        });
    }

    function updateEmailCount() {
        $('#emailCount').text($('.followup-check:checked').length + ' selected');
    }

    function downloadTemplate() {
        const csv = "Student Name,Action,Due Date,Notes\nJohn Doe,Call,2026-07-15,Confirm documents received\n";
        const blob = new Blob([csv], {type: "text/csv"});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = "followup_template.csv";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 1000);
    }

    $(function () {
        $(document).on('click', '.status-chip', function () {
            const $chip = $(this);
            $.ajax({
                url: $chip.data('cycle-url'),
                method: 'PATCH',
                success: function (data) {
                    $chip.text(data.status);
                    $chip.removeClass('teal gold gray amber');
                    const map = { Registered: 'teal', Visit: 'gold', New: 'gray' };
                    $chip.addClass(map[data.status] || 'amber');
                }
            });
        });

        $('#emailSendBtn').on('click', function () {
            const names = $('.followup-check:checked').map(function () {
                return $(this).closest('.fu-card').find('.fu-name').text().trim();
            }).get();
            if (names.length === 0) return;
            $('#emailConfirm').show().text('✓ Emailed ' + names.length + ': ' + names.join(', ') + ' — (demo only; connect an email provider like SendGrid/SES to send for real)');
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\guiders\resources\views/leads/follow-ups.blade.php ENDPATH**/ ?>