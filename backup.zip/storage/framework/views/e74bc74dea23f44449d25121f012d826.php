<?php $__env->startSection('title', 'User Management'); ?>
<?php $__env->startSection('subtitle', 'Create accounts and manage roles across the platform'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel">
        <div class="panel-head">
            <div><h2>All Users</h2><p><?php echo e($users->count()); ?> accounts</p></div>
            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="collapse" data-bs-target="#userForm">
                + Add User
            </button>
        </div>

        <div class="collapse" id="userForm">
            <form method="POST" action="<?php echo e(route('users.store')); ?>" class="form-row">
                <?php echo csrf_field(); ?>
                <input class="form-control" name="name" placeholder="Full name" required>
                <input class="form-control" type="email" name="email" placeholder="Email address" required>
                <input class="form-control" type="password" name="password" placeholder="Password (min 8 characters)" required>
                <select class="form-select" name="role" required>
                    <option value="admin">Admin</option>
                    <option value="processing_team">Processing Team</option>
                    <option value="counselor" selected>Counselor</option>
                    <option value="student">Student</option>
                    <option value="partner">Partner Company</option>
                </select>
                <button class="btn btn-primary" type="submit">Save</button>
            </form>
            <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="px-3 pb-3 text-danger small"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Joined</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="name-cell"><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <span class="chip static <?php echo e(match($user->role) {
                                    'admin' => 'amber',
                                    'processing_team' => 'teal',
                                    'counselor' => 'gray',
                                    'partner' => 'gray',
                                    default => 'gray',
                                }); ?>"><?php echo e($roleLabels[$user->role] ?? $user->role); ?></span>
                                <?php if($user->is(auth()->user())): ?>
                                    <span class="sub-cell">(you)</span>
                                <?php endif; ?>
                            </td>
                            <td class="date-cell"><?php echo e($user->created_at->toDateString()); ?></td>
                            <td class="text-end">
                                <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="collapse" data-bs-target="#editUser<?php echo e($user->id); ?>">
                                    Edit
                                </button>
                                <?php if (! ($user->is(auth()->user()))): ?>
                                    <form method="POST" action="<?php echo e(route('users.destroy', $user)); ?>" class="d-inline" onsubmit="return confirm('Delete <?php echo e($user->name); ?>? This cannot be undone.');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr class="collapse" id="editUser<?php echo e($user->id); ?>">
                            <td colspan="5" class="p-0">
                                <form method="POST" action="<?php echo e(route('users.update', $user)); ?>" class="form-row">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <input class="form-control" name="name" value="<?php echo e($user->name); ?>" required>
                                    <input class="form-control" type="email" name="email" value="<?php echo e($user->email); ?>" required>
                                    <input class="form-control" type="password" name="password" placeholder="New password (leave blank to keep current)">
                                    <select class="form-select" name="role" required>
                                        <?php $__currentLoopData = $roleLabels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value); ?>" <?php if($user->role === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button class="btn btn-primary" type="submit">Update</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="empty-state">No users yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\guiders\resources\views/users/index.blade.php ENDPATH**/ ?>