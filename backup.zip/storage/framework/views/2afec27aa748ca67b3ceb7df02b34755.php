<?php $__env->startSection('title', 'Suggest for Client'); ?>
<?php $__env->startSection('subtitle', "Enter a client's interest and budget to get matching programs"); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel">
        <div class="panel-head">
            <div><h2>Match Finder</h2><p>&nbsp;</p></div>
        </div>

        <div class="suggest-form">
            <div>
                <label>Client name (optional)</label>
                <input id="suggestClient" class="form-control form-control-sm" placeholder="e.g. Hamza Tariq">
            </div>
            <div>
                <label>Interest / program</label>
                <input id="suggestKeyword" class="form-control form-control-sm" placeholder="e.g. MBA, Data Science">
            </div>
            <div>
                <label>Budget</label>
                <input id="suggestBudget" type="number" class="form-control form-control-sm" placeholder="e.g. 2000">
            </div>
            <div>
                <button id="suggestBtn" class="btn btn-primary btn-sm" type="button">Find Matches</button>
            </div>
        </div>

        <div class="board" id="suggestBoard">
            <div class="board-empty">Enter a keyword or budget above and click Find Matches.</div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(function () {
        $('#suggestBtn').on('click', function () {
            $.get('<?php echo e(route('suggest.search')); ?>', {
                q: $('#suggestKeyword').val(),
                budget: $('#suggestBudget').val(),
            }, function (html) {
                $('#suggestBoard').html(html);
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u943754902/domains/deekod.com/public_html/guiders/resources/views/suggest/index.blade.php ENDPATH**/ ?>