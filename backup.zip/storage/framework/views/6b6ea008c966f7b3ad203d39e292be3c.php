<?php $__env->startSection('title', 'Follow-ups'); ?>
<?php $__env->startSection('subtitle', "Each lead's profile, suggestion, and remarks — saved as you type"); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel">
        <div class="panel-head">
            <div><h2>Bulk Import (optional)</h2><p>Upload a legacy tracking sheet — columns: Student Name, Action, Due Date</p></div>
        </div>
        <form method="POST" action="<?php echo e(route('followups.upload')); ?>" enctype="multipart/form-data" class="upload-row">
            <?php echo csrf_field(); ?>
            <input type="file" name="file" accept=".csv,.txt" class="form-control form-control-sm" style="max-width:280px" required>
            <button class="btn btn-outline-primary btn-sm" type="submit">Upload sheet</button>
            <a href="<?php echo e(route('followups.template')); ?>" class="btn btn-outline-secondary btn-sm">Download blank template</a>
        </form>
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php $reminders = $followUpsByLead->get($lead->id, collect()); ?>
        <div class="fu-card" data-lead-id="<?php echo e($lead->id); ?>">
            <div class="fu-head">
                <div class="fu-name">
                    <?php echo e($lead->name); ?>

                    <span class="sub-cell"><?php echo e($lead->contact ?: 'No contact on file'); ?> &middot; <?php echo e($lead->source); ?></span>
                </div>
                <span class="chip status-chip
                    <?php echo e(match($lead->status) {
                        'Registered' => 'teal',
                        'Visit' => 'gold',
                        'New' => 'gray',
                        default => 'amber',
                    }); ?>" data-cycle-url="<?php echo e(route('leads.cycle-status', $lead)); ?>">
                    <?php echo e($lead->status); ?>

                </span>
            </div>
            <div class="fu-body">
                <div class="profile-grid">
                    <input class="form-control profile-field" name="desired_program" placeholder="Desired program" value="<?php echo e($lead->desired_program); ?>">
                    <input class="form-control profile-field" name="country" placeholder="Desired country" value="<?php echo e($lead->country); ?>">
                    <input class="form-control profile-field" type="number" step="0.01" name="budget" placeholder="Budget (USD)" value="<?php echo e($lead->budget); ?>">
                    <input class="form-control profile-field" name="last_qualification" placeholder="Last qualification" value="<?php echo e($lead->last_qualification); ?>">
                    <input class="form-control profile-field" name="cgpa" placeholder="CGPA" value="<?php echo e($lead->cgpa); ?>">
                    <input class="form-control profile-field" type="number" name="age" placeholder="Age" value="<?php echo e($lead->age); ?>">
                    <input class="form-control profile-field" name="city" placeholder="City" value="<?php echo e($lead->city); ?>">
                </div>
                <div class="profile-grid profile-grid-notes">
                    <textarea class="form-control profile-field" name="suggestion" placeholder="Suggestion — what you recommended" rows="2"><?php echo e($lead->suggestion); ?></textarea>
                    <textarea class="form-control profile-field" name="remarks" placeholder="Remarks — how it went" rows="2"><?php echo e($lead->remarks); ?></textarea>
                </div>
                <div class="fu-save-status" data-for="<?php echo e($lead->id); ?>"></div>

                <div class="fu-reminders">
                    <?php $__empty_2 = true; $__currentLoopData = $reminders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reminder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <div class="fu-reminder-row <?php echo e($reminder->isOverdue() ? 'overdue-row' : ($reminder->isDueSoon() ? 'due-soon-row' : '')); ?>">
                            <span class="chip action-chip <?php echo e($reminder->action === 'Visit' ? 'gold' : 'amber'); ?>"
                                  data-url="<?php echo e(route('followups.cycle-action', $reminder)); ?>">
                                <?php echo e($reminder->action); ?>

                            </span>
                            <span class="date-cell due-date"><?php echo e($reminder->due_date->toDateString()); ?><?php echo e($reminder->isOverdue() ? ' (overdue)' : ''); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <div class="sub-cell">No reminders scheduled yet.</div>
                    <?php endif; ?>
                </div>

                <form method="POST" action="<?php echo e(route('followups.store')); ?>" class="fu-add-reminder">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="lead_id" value="<?php echo e($lead->id); ?>">
                    <input type="hidden" name="student_name" value="<?php echo e($lead->name); ?>">
                    <select class="form-select form-select-sm" name="action">
                        <option value="Call">Call</option>
                        <option value="Visit">Visit</option>
                    </select>
                    <input class="form-control form-control-sm" type="date" name="due_date" required>
                    <button class="btn btn-outline-primary btn-sm" type="submit">+ Add reminder</button>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="panel"><div class="empty-state">No leads yet — add one from My Leads to start tracking follow-ups.</div></div>
    <?php endif; ?>

    <?php if($unlinked->isNotEmpty()): ?>
        <div class="panel">
            <div class="panel-head"><div><h2>Other reminders</h2><p>Not linked to a lead (e.g. imported from a sheet)</p></div></div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead><tr><th>Student</th><th>Action</th><th>Due</th></tr></thead>
                    <tbody>
                        <?php $__currentLoopData = $unlinked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reminder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="<?php echo e($reminder->isOverdue() ? 'overdue-row' : ($reminder->isDueSoon() ? 'due-soon-row' : '')); ?>">
                                <td class="name-cell"><?php echo e($reminder->student_name); ?></td>
                                <td>
                                    <span class="chip action-chip <?php echo e($reminder->action === 'Visit' ? 'gold' : 'amber'); ?>"
                                          data-url="<?php echo e(route('followups.cycle-action', $reminder)); ?>">
                                        <?php echo e($reminder->action); ?>

                                    </span>
                                </td>
                                <td class="date-cell due-date"><?php echo e($reminder->due_date->toDateString()); ?><?php echo e($reminder->isOverdue() ? ' (overdue)' : ''); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>

    <div class="modal fade" id="visitDateModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Schedule visit</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <label class="form-label small">Visit date</label>
                    <input type="date" id="visitDateInput" class="form-control" required>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="visitDateConfirm" class="btn btn-primary btn-sm">Confirm visit</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(function () {
        // Inline auto-save: any change to a profile/suggestion/remarks field saves the whole card
        let saveTimers = {};
        $(document).on('input change', '.profile-field', function () {
            const $card = $(this).closest('.fu-card');
            const leadId = $card.data('lead-id');
            const $status = $card.find('.fu-save-status');

            clearTimeout(saveTimers[leadId]);
            saveTimers[leadId] = setTimeout(function () {
                const payload = {};
                $card.find('.profile-field').each(function () {
                    payload[$(this).attr('name')] = $(this).val();
                });

                $status.text('Saving…');
                $.ajax({
                    url: '/leads/' + leadId + '/profile',
                    method: 'PATCH',
                    dataType: 'json',
                    headers: { Accept: 'application/json' },
                    data: payload,
                    success: function () {
                        $status.text('Saved ✓');
                        setTimeout(() => $status.text(''), 1500);
                    },
                    error: function () {
                        $status.text('Could not save — check required fields.');
                    }
                });
            }, 600);
        });

        $(document).on('click', '.status-chip', function () {
            const $chip = $(this);
            $.ajax({
                url: $chip.data('cycle-url'),
                method: 'PATCH',
                success: function (data) {
                    $chip.text(data.status);
                    $chip.removeClass('teal gold gray amber');
                    const map = { Registered: 'teal', Visit: 'gold', New: 'gray' };
                    $chip.addClass(map[data.status] || 'amber');
                }
            });
        });

        let $pendingChip = null;
        const visitModal = new bootstrap.Modal(document.getElementById('visitDateModal'));

        $(document).on('click', '.action-chip', function () {
            const $chip = $(this);
            const current = $chip.text().trim();
            const next = current === 'Call' ? 'Visit' : 'Call';

            if (next === 'Visit') {
                $pendingChip = $chip;
                $('#visitDateInput').val($chip.closest('.fu-reminder-row, tr').find('.due-date').text().trim().split(' ')[0]);
                visitModal.show();
                return;
            }

            $.ajax({ url: $chip.data('url'), method: 'PATCH', success: function (data) {
                applyAction($chip, data);
            }});
        });

        $('#visitDateConfirm').on('click', function () {
            const date = $('#visitDateInput').val();
            if (!date || !$pendingChip) return;

            $.ajax({
                url: $pendingChip.data('url'),
                method: 'PATCH',
                data: { due_date: date },
                success: function (data) {
                    applyAction($pendingChip, data);
                    visitModal.hide();
                    $pendingChip = null;
                }
            });
        });

        function applyAction($chip, data) {
            $chip.text(data.action);
            $chip.removeClass('amber gold').addClass(data.action === 'Visit' ? 'gold' : 'amber');
            $chip.closest('.fu-reminder-row, tr').find('.due-date').text(data.due_date);
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\guiders\resources\views/followups/index.blade.php ENDPATH**/ ?>