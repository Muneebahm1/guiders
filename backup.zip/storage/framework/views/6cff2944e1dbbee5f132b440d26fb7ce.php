<?php
    $user = auth()->user();
    $roleLabels = \App\Models\User::roleLabels();
?>

<div class="sidebar">
    <div class="brand-block">
        <img src="<?php echo e(asset('img/logo/logoguidr.png')); ?>" alt="The Guiders" class="brand-logo">
        <div class="brand-text">
            <div class="brand">THE GUIDERS</div>
            <div class="brand-sub">Overseas Educational Services</div>
        </div>
    </div>

    <div class="nav-label"><?php echo e($roleLabels[$user->role]); ?></div>

    <?php if($user->hasBackOfficeAccess()): ?>
        <a href="<?php echo e(route('home')); ?>" class="nav-item <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">
            <span class="nav-dot"></span>Dashboard
        </a>
    <?php endif; ?>

    <?php if($user->hasBackOfficeAccess()): ?>
        <a href="<?php echo e(route('opportunities.index')); ?>" class="nav-item <?php echo e(request()->routeIs('opportunities.*') ? 'active' : ''); ?>">
            <span class="nav-dot"></span>Opportunities
        </a>
        <a href="<?php echo e(route('students.index')); ?>" class="nav-item <?php echo e(request()->routeIs('students.*') ? 'active' : ''); ?>">
            <span class="nav-dot"></span>Study Abroad Students
        </a>
        <a href="<?php echo e(route('papers.index')); ?>" class="nav-item <?php echo e(request()->routeIs('papers.*') ? 'active' : ''); ?>">
            <span class="nav-dot"></span>Research Papers
        </a>
    <?php endif; ?>

    <?php if($user->isAdmin()): ?>
        <div class="nav-label">Administration</div>
        <a href="<?php echo e(route('users.index')); ?>" class="nav-item <?php echo e(request()->routeIs('users.*') ? 'active' : ''); ?>">
            <span class="nav-dot"></span>User Management
        </a>
        <a href="<?php echo e(route('activity.index')); ?>" class="nav-item <?php echo e(request()->routeIs('activity.*') ? 'active' : ''); ?>">
            <span class="nav-dot"></span>Activity Log
        </a>
        <a href="<?php echo e(route('leads.all')); ?>" class="nav-item <?php echo e(request()->routeIs('leads.all') ? 'active' : ''); ?>">
            <span class="nav-dot"></span>All Leads
        </a>
        <a href="<?php echo e(route('followups.all')); ?>" class="nav-item <?php echo e(request()->routeIs('followups.all') ? 'active' : ''); ?>">
            <span class="nav-dot"></span>All Follow-ups
        </a>
    <?php endif; ?>

    <?php if($user->isCounselor()): ?>
        <a href="<?php echo e(route('leads.index')); ?>" class="nav-item <?php echo e(request()->routeIs('leads.*') ? 'active' : ''); ?>">
            <span class="nav-dot"></span>My Leads
        </a>
        <a href="<?php echo e(route('students.index')); ?>" class="nav-item <?php echo e(request()->routeIs('students.*') ? 'active' : ''); ?>">
            <span class="nav-dot"></span>My Study Abroad Students
        </a>
        <a href="<?php echo e(route('papers.index')); ?>" class="nav-item <?php echo e(request()->routeIs('papers.*') ? 'active' : ''); ?>">
            <span class="nav-dot"></span>My Research Papers
        </a>
        <a href="<?php echo e(route('opportunities.index')); ?>" class="nav-item <?php echo e(request()->routeIs('opportunities.*') ? 'active' : ''); ?>">
            <span class="nav-dot"></span>Browse Opportunities
        </a>
        <a href="<?php echo e(route('suggest.index')); ?>" class="nav-item <?php echo e(request()->routeIs('suggest.*') ? 'active' : ''); ?>">
            <span class="nav-dot"></span>Suggest for Client
        </a>
        <a href="<?php echo e(route('leads.follow-ups')); ?>" class="nav-item <?php echo e(request()->routeIs('leads.follow-ups') ? 'active' : ''); ?>">
            <span class="nav-dot"></span>Follow-ups
        </a>
    <?php endif; ?>

    <?php if($user->isStudent()): ?>
        <a href="<?php echo e(route('students.index')); ?>" class="nav-item <?php echo e(request()->routeIs('students.*') ? 'active' : ''); ?>">
            <span class="nav-dot"></span>My Progress
        </a>
    <?php endif; ?>

    <?php if($user->isPartner()): ?>
        <a href="<?php echo e(route('students.index')); ?>" class="nav-item <?php echo e(request()->routeIs('students.*') ? 'active' : ''); ?>">
            <span class="nav-dot"></span>My Registered Students
        </a>
        <a href="<?php echo e(route('opportunities.index')); ?>" class="nav-item <?php echo e(request()->routeIs('opportunities.*') ? 'active' : ''); ?>">
            <span class="nav-dot"></span>Opportunities
        </a>
    <?php endif; ?>

    <div class="access-note">
        <?php if($user->isAdmin()): ?>
            Full access: opportunities, students, papers, user accounts, the activity log, and read-only visibility into every counselor's leads and follow-ups.
        <?php elseif($user->isProcessingTeam()): ?>
            Can add and edit opportunities, and update application, fee, visa, and paper-review progress for any student across all counselors. No access to leads.
        <?php elseif($user->isCounselor()): ?>
            Can manage own leads, students, and paper submissions. Can browse all opportunities, get budget-matched suggestions, and track follow-ups. Cannot add opportunities.
        <?php elseif($user->isStudent()): ?>
            Read-only view of your own case. Nothing here can be edited by you.
        <?php else: ?>
            Can view all opportunities and register new students you've referred. Only sees your own referred students.
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\guiders\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>