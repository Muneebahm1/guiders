<?php $__env->startSection('title', 'Clearance Report — '.$application->student->name); ?>
<?php $__env->startSection('subtitle', $application->opportunity->name ?? 'Application'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel print-area">
        <div class="panel-head">
            <div>
                <h2>Dues Clearance Report</h2>
                <p><?php echo e($application->student->name); ?> &mdash; <?php echo e($application->opportunity->name ?? 'No program'); ?></p>
            </div>
            <button type="button" class="btn btn-outline-secondary btn-sm no-print" onclick="window.print()">Print</button>
        </div>

        <div class="p-3">
            <?php if($clearance->signed_off): ?>
                <div class="alert alert-success">
                    Signed off by <?php echo e($clearance->signedOffBy->name ?? 'staff'); ?> on <?php echo e($clearance->signed_off_at?->toDateString()); ?> &mdash; cleared to travel.
                </div>
            <?php endif; ?>

            <table class="table table-sm mb-4">
                <thead><tr><th>Installment</th><th>Amount</th><th>Due</th><th>Paid</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $application->installments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $installment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($installment->title); ?></td>
                            <td><?php echo e($installment->currency); ?> <?php echo e(number_format($installment->amount, 2)); ?></td>
                            <td><?php echo e($installment->due_date->toDateString()); ?></td>
                            <td><?php echo e($installment->paid_date?->toDateString() ?? 'Unpaid'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4" class="empty-state">No installments recorded.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <form method="POST" action="<?php echo e(route('clearance.update', $application)); ?>" class="no-print">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger"><?php echo e($errors->first()); ?></div>
                <?php endif; ?>

                <div class="form-check mb-2">
                    <input class="form-check-input" type="checkbox" name="tuition_cleared" value="1" id="tuition_cleared" <?php echo e($clearance->tuition_cleared ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="tuition_cleared">Tuition fees cleared</label>
                </div>
                <div class="form-check mb-3">
                    <input class="form-check-input" type="checkbox" name="service_dues_cleared" value="1" id="service_dues_cleared" <?php echo e($clearance->service_dues_cleared ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="service_dues_cleared">Service dues cleared</label>
                </div>

                <textarea class="form-control mb-3" name="remarks" rows="3" placeholder="Remarks"><?php echo e($clearance->remarks); ?></textarea>

                <div class="form-check mb-3">
                    <input class="form-check-input" type="checkbox" name="signed_off" value="1" id="signed_off" <?php echo e($clearance->signed_off ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="signed_off">Sign off &mdash; cleared to travel (requires all installments paid)</label>
                </div>

                <button type="submit" class="btn btn-primary">Save</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    @media print {
        .sidebar, .topbar, .no-print { display: none !important; }
    }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u943754902/domains/deekod.com/public_html/guiders/resources/views/clearance/show.blade.php ENDPATH**/ ?>