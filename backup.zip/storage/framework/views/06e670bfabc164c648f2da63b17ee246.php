<?php $__env->startSection('title', 'Activity Log'); ?>
<?php $__env->startSection('subtitle', 'Recent actions across the platform — most recent 200 events'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel">
        <div class="panel-head">
            <div><h2>Activity</h2><p>Opportunities, leads, students, papers, and user accounts</p></div>
        </div>

        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>When</th>
                        <th>User</th>
                        <th>Action</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="date-cell"><?php echo e($log->created_at->format('Y-m-d H:i')); ?></td>
                            <td class="name-cell"><?php echo e($log->user->name ?? 'System'); ?></td>
                            <td><span class="chip static gray"><?php echo e($log->action); ?></span></td>
                            <td><?php echo e($log->description); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4" class="empty-state">No activity recorded yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\guiders\resources\views/activity/index.blade.php ENDPATH**/ ?>