<?php $__env->startSection('title', auth()->user()->hasBackOfficeAccess() ? 'Study Abroad — All Students' : 'My Study Abroad Students'); ?>
<?php $__env->startSection('subtitle', auth()->user()->hasBackOfficeAccess() ? 'Application through visa, across all counselors' : 'Open a student to manage their applications'); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials._reminder_banner', ['reminders' => $reminders ?? collect()], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php if(auth()->user()->isCounselor() && $unassigned->isNotEmpty()): ?>
        <div class="panel">
            <div class="panel-head">
                <div><h2>Unassigned students</h2><p>Self-registered, not yet claimed by a counselor</p></div>
            </div>
            <ul class="list-group list-group-flush">
                <?php $__currentLoopData = $unassigned; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <span><?php echo e($student->name); ?></span>
                        <form method="POST" action="<?php echo e(route('students.claim', $student)); ?>" class="d-flex gap-2">
                            <?php echo csrf_field(); ?>
                            <select name="opportunity_id" class="form-select form-select-sm">
                                <option value="">Choose program/journal&hellip;</option>
                                <?php $__currentLoopData = $opportunities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opportunity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($opportunity->id); ?>"><?php echo e($opportunity->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button class="btn btn-sm btn-outline-primary" type="submit">Claim</button>
                        </form>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="panel">
        <div class="panel-head">
            <div><h2>Students</h2><p>&nbsp;</p></div>
        </div>

        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Student</th>
                        <?php if(auth()->user()->hasBackOfficeAccess()): ?>
                            <th>Counselor</th>
                        <?php endif; ?>
                        <th>Applications</th>
                        <th>Most urgent status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $urgent = $student->applications->sortBy(function ($a) {
                                return match(true) {
                                    $a->fee_status === 'Overdue' => 0,
                                    $a->visa_stage === 'Rejected' || $a->app_stage === 'Rejected' => 1,
                                    $a->travel_status !== 'Not Ready' => 2,
                                    default => 3,
                                };
                            })->first();
                        ?>
                        <tr>
                            <td class="name-cell"><?php echo e($student->name); ?></td>
                            <?php if(auth()->user()->hasBackOfficeAccess()): ?>
                                <td><?php echo e($student->counselor->name ?? ($student->partner ? 'Partner: '.$student->partner->name : '—')); ?></td>
                            <?php endif; ?>
                            <td><?php echo e($student->applications->count()); ?></td>
                            <td>
                                <?php if($urgent): ?>
                                    <span class="chip static <?php echo e($urgent->fee_status === 'Overdue' ? 'coral' : 'amber'); ?>">
                                        <?php echo e($urgent->opportunity->name ?? 'Application'); ?> — <?php echo e($urgent->app_stage); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="chip static gray">No applications yet</span>
                                <?php endif; ?>
                            </td>
                            <td><a href="<?php echo e(route('students.detail', $student)); ?>" class="btn btn-sm btn-outline-primary">View</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="empty-state">No students yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u943754902/domains/deekod.com/public_html/guiders/resources/views/students/index.blade.php ENDPATH**/ ?>