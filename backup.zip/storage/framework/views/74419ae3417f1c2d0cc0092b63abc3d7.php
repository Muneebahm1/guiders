<?php $__env->startSection('title', $student->name); ?>
<?php $__env->startSection('subtitle', 'All applications for this student'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel">
        <div class="panel-head">
            <div>
                <h2><?php echo e($student->name); ?></h2>
                <p>Counselor: <?php echo e($student->counselor->name ?? ($student->partner ? 'Partner: '.$student->partner->name : 'Unassigned')); ?></p>
            </div>
            <div class="d-flex gap-2">
                <a href="<?php echo e(route('invoices.create', ['student_id' => $student->id])); ?>" class="btn btn-primary btn-sm">Generate Invoice</a>
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-toggle="collapse" data-bs-target="#addApplication">
                    + Add Application
                </button>
            </div>
        </div>

        <div class="collapse" id="addApplication">
            <form method="POST" action="<?php echo e(route('applications.store', $student)); ?>" class="form-row p-3 border-top">
                <?php echo csrf_field(); ?>
                <select class="form-select" name="opportunity_id" required>
                    <option value="">Choose program/journal&hellip;</option>
                    <?php $__currentLoopData = $opportunities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opportunity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($opportunity->id); ?>"><?php echo e($opportunity->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button class="btn btn-primary" type="submit">Add</button>
            </form>
        </div>
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $student->applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php echo $__env->make('students._application_timeline', ['application' => $application, 'editable' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="panel"><p class="empty-state">No applications yet — add one above.</p></div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(function () {
        const appColors = { Accepted: 'teal', Rejected: 'coral', 'Not Applied': 'gray' };
        const visaColors = { Approved: 'teal', Rejected: 'coral', 'Not Started': 'gray' };
        const travelColors = { Travelled: 'teal', 'Cleared to Travel': 'gold' };
        const allColors = ['teal', 'coral', 'gray', 'amber', 'gold'];

        $(document).on('click', '.app-stage-chip', function () {
            const $chip = $(this);
            $.ajax({ url: $chip.data('url'), method: 'PATCH', success: function (data) {
                $chip.text(data.app_stage);
                $chip.removeClass(allColors.join(' ')).addClass(appColors[data.app_stage] || 'amber');
            }});
        });

        $(document).on('click', '.visa-stage-chip', function () {
            const $chip = $(this);
            $.ajax({ url: $chip.data('url'), method: 'PATCH', success: function (data) {
                $chip.text(data.visa_stage);
                $chip.removeClass(allColors.join(' ')).addClass(visaColors[data.visa_stage] || 'amber');
            }});
        });

        $(document).on('click', '.travel-status-chip', function () {
            const $chip = $(this);
            $.ajax({
                url: $chip.data('url'), method: 'PATCH',
                success: function (data) {
                    $chip.text(data.travel_status);
                    $chip.removeClass(allColors.join(' ')).addClass(travelColors[data.travel_status] || 'gray');
                },
                error: function (xhr) {
                    alert(xhr.responseJSON?.error || 'Could not update travel status.');
                },
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u943754902/domains/deekod.com/public_html/guiders/resources/views/students/detail.blade.php ENDPATH**/ ?>