<?php $__env->startSection('title', auth()->user()->hasBackOfficeAccess() ? 'Research Publication — All Submissions' : 'My Research Papers'); ?>
<?php $__env->startSection('subtitle', auth()->user()->hasBackOfficeAccess() ? 'Time in review is tracked from submission date' : 'Click status to advance through review'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel">
        <div class="panel-head">
            <div><h2>Submissions</h2><p>&nbsp;</p></div>
            <?php if(auth()->user()->isCounselor()): ?>
                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="collapse" data-bs-target="#paperForm">
                    + Log Submission
                </button>
            <?php endif; ?>
        </div>

        <?php if(auth()->user()->isCounselor()): ?>
            <div class="collapse" id="paperForm">
                <form method="POST" action="<?php echo e(route('papers.store')); ?>" class="form-row">
                    <?php echo csrf_field(); ?>
                    <input class="form-control" name="author_name" placeholder="Author / student name" required>
                    <select class="form-select" name="opportunity_id" required>
                        <option value="">Choose journal&hellip;</option>
                        <?php $__currentLoopData = $journals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $journal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($journal->id); ?>"><?php echo e($journal->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input class="form-control" type="date" name="submitted_date" required>
                    <button class="btn btn-primary" type="submit">Save</button>
                </form>
            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Author</th>
                        <?php if(auth()->user()->hasBackOfficeAccess()): ?>
                            <th>Counselor</th>
                        <?php endif; ?>
                        <th>Journal</th>
                        <th>Submitted</th>
                        <th>In review</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $papers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="name-cell"><?php echo e($paper->author_name); ?></td>
                            <?php if(auth()->user()->hasBackOfficeAccess()): ?>
                                <td><?php echo e($paper->counselor->name); ?></td>
                            <?php endif; ?>
                            <td><?php echo e($paper->opportunity->name); ?></td>
                            <td class="date-cell"><?php echo e($paper->submitted_date->toDateString()); ?></td>
                            <td class="review-days"><?php echo e($paper->daysInReview()); ?>d</td>
                            <td>
                                <span class="chip paper-status-chip
                                    <?php echo e(match($paper->status) {
                                        'Accepted' => 'teal',
                                        'Rejected' => 'coral',
                                        default => 'amber',
                                    }); ?>" data-url="<?php echo e(route('papers.cycle-status', $paper)); ?>">
                                    <?php echo e($paper->status); ?>

                                </span>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6" class="empty-state">No submissions yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(function () {
        $(document).on('click', '.paper-status-chip', function () {
            const $chip = $(this);
            $.ajax({ url: $chip.data('url'), method: 'PATCH', success: function (data) {
                $chip.text(data.status);
                $chip.removeClass('teal coral amber');
                const map = { Accepted: 'teal', Rejected: 'coral' };
                $chip.addClass(map[data.status] || 'amber');
            }});
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u943754902/domains/deekod.com/public_html/guiders/resources/views/papers/index.blade.php ENDPATH**/ ?>