<?php $__env->startSection('title', 'All Follow-ups'); ?>
<?php $__env->startSection('subtitle', 'Every scheduled call/visit reminder across all counselors — read-only'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel">
        <div class="panel-head">
            <div><h2>Follow-ups</h2><p><?php echo e($followUps->count()); ?> total</p></div>
        </div>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Counselor</th>
                        <th>Linked lead</th>
                        <th>Action</th>
                        <th>Due</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $followUps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $followUp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="<?php echo e($followUp->isOverdue() ? 'overdue-row' : ($followUp->isDueSoon() ? 'due-soon-row' : '')); ?>">
                            <td class="name-cell"><?php echo e($followUp->student_name); ?></td>
                            <td><?php echo e($followUp->counselor->name ?? '—'); ?></td>
                            <td><?php echo e($followUp->lead->name ?? '—'); ?></td>
                            <td><span class="chip static <?php echo e($followUp->action === 'Visit' ? 'gold' : 'amber'); ?>"><?php echo e($followUp->action); ?></span></td>
                            <td class="date-cell"><?php echo e($followUp->due_date->toDateString()); ?><?php echo e($followUp->isOverdue() ? ' (overdue)' : ''); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="empty-state">No follow-ups yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u943754902/domains/deekod.com/public_html/guiders/resources/views/followups/all.blade.php ENDPATH**/ ?>