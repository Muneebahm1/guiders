<?php $__env->startSection('title', 'My Registered Students'); ?>
<?php $__env->startSection('subtitle', "Students you've referred, and where their case stands"); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel">
        <div class="panel-head">
            <div><h2>Registered Students</h2><p>&nbsp;</p></div>
            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="collapse" data-bs-target="#partnerForm">
                + Register Student
            </button>
        </div>

        <div class="collapse" id="partnerForm">
            <form method="POST" action="<?php echo e(route('students.register')); ?>" class="form-row">
                <?php echo csrf_field(); ?>
                <input class="form-control" name="name" placeholder="Student full name" required>
                <select class="form-select" name="opportunity_id" required>
                    <option value="">Choose program&hellip;</option>
                    <?php $__currentLoopData = $opportunities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opportunity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($opportunity->id); ?>"><?php echo e($opportunity->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button class="btn btn-primary" type="submit">Save</button>
            </form>
        </div>

        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Program</th>
                        <th>Application</th>
                        <th>Fee</th>
                        <th>Visa</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $appClass = match($student->app_stage) {
                                'Accepted' => 'teal', 'Rejected' => 'coral', 'Not Applied' => 'gray', default => 'amber',
                            };
                            $visaClass = match($student->visa_stage) {
                                'Visa Approved' => 'teal', 'Visa Rejected' => 'coral', 'Not Started' => 'gray', default => 'amber',
                            };
                        ?>
                        <tr>
                            <td class="name-cell"><?php echo e($student->name); ?></td>
                            <td><?php echo e($student->opportunity->name ?? '—'); ?></td>
                            <td><span class="chip static <?php echo e($appClass); ?>"><?php echo e($student->app_stage); ?></span></td>
                            <td class="date-cell"><?php echo e($student->fee_date?->toDateString() ?? '—'); ?></td>
                            <td>
                                <span class="chip static <?php echo e($visaClass); ?>"><?php echo e($student->visa_stage); ?></span>
                                <?php if($student->visa_date): ?>
                                    <div class="sub-cell">Filed <?php echo e($student->visa_date->toDateString()); ?></div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="empty-state">No students registered yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\guiders\resources\views/students/partner.blade.php ENDPATH**/ ?>