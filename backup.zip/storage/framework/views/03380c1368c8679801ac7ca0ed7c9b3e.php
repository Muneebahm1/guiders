<?php $__env->startSection('title', 'Staff Monthly Report'); ?>
<?php $__env->startSection('subtitle', 'Leads, follow-ups, applications, and collections by counselor'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel">
        <div class="panel-head">
            <div><h2>Filters</h2><p>&nbsp;</p></div>
        </div>
        <form method="GET" action="<?php echo e(route('reports.staff')); ?>" class="form-row p-3">
            <input class="form-control" type="month" name="month" value="<?php echo e($month); ?>">
            <select class="form-select" name="counselor_id">
                <option value="">All counselors</option>
                <?php $__currentLoopData = $allCounselors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counselor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($counselor->id); ?>" <?php echo e($selectedCounselorId == $counselor->id ? 'selected' : ''); ?>><?php echo e($counselor->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button class="btn btn-primary" type="submit">Apply</button>
        </form>
    </div>

    <div class="panel">
        <div class="panel-head">
            <div><h2>Counselor Activity — <?php echo e(\Illuminate\Support\Carbon::createFromFormat('Y-m', $month)->format('F Y')); ?></h2><p>&nbsp;</p></div>
        </div>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Counselor</th>
                        <th>Leads added</th>
                        <th>Follow-ups logged</th>
                        <th>Students registered</th>
                        <th>Applications added</th>
                        <th>Amount collected</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="name-cell"><?php echo e($row['counselor']->name); ?></td>
                            <td><?php echo e($row['leads_added']); ?></td>
                            <td><?php echo e($row['follow_ups_logged']); ?></td>
                            <td><?php echo e($row['students_registered']); ?></td>
                            <td><?php echo e($row['applications_added']); ?></td>
                            <td><?php echo e(number_format($row['amount_collected'], 2)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6" class="empty-state">No counselors found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u943754902/domains/deekod.com/public_html/guiders/resources/views/reports/staff.blade.php ENDPATH**/ ?>