<?php $__env->startSection('title', 'Company Settings'); ?>
<?php $__env->startSection('subtitle', 'Bank/payment account details shown on every generated invoice'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel">
        <div class="panel-head">
            <div><h2>Company &amp; Bank Details</h2><p>Only admins can change these</p></div>
        </div>

        <form method="POST" action="<?php echo e(route('company-settings.update')); ?>" class="p-3">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="mb-3">
                <label class="form-label">Company name</label>
                <input class="form-control" name="company_name" value="<?php echo e(old('company_name', $company->company_name)); ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Address</label>
                <textarea class="form-control" name="address" rows="2"><?php echo e(old('address', $company->address)); ?></textarea>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-md-6">
                    <label class="form-label">Bank name</label>
                    <input class="form-control" name="bank_name" value="<?php echo e(old('bank_name', $company->bank_name)); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Account number</label>
                    <input class="form-control" name="account_number" value="<?php echo e(old('account_number', $company->account_number)); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Branch code</label>
                    <input class="form-control" name="branch_code" value="<?php echo e(old('branch_code', $company->branch_code)); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">IBAN</label>
                    <input class="form-control" name="iban" value="<?php echo e(old('iban', $company->iban)); ?>">
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label">Default invoice notes</label>
                <textarea class="form-control" name="notes" rows="2"><?php echo e(old('notes', $company->notes)); ?></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Default invoice terms</label>
                <textarea class="form-control" name="terms" rows="2"><?php echo e(old('terms', $company->terms)); ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Save</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u943754902/domains/deekod.com/public_html/guiders/resources/views/company-settings/edit.blade.php ENDPATH**/ ?>