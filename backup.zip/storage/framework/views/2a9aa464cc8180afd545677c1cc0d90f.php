<?php $__env->startSection('title', auth()->user()->hasBackOfficeAccess() ? 'Study Abroad — All Students' : 'My Study Abroad Students'); ?>
<?php $__env->startSection('subtitle', auth()->user()->hasBackOfficeAccess() ? 'Application through visa, across all counselors' : 'Click a status to move it to the next stage'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()->isCounselor() && $unassigned->isNotEmpty()): ?>
        <div class="panel">
            <div class="panel-head">
                <div><h2>Unassigned students</h2><p>Self-registered, not yet claimed by a counselor</p></div>
            </div>
            <ul class="list-group list-group-flush">
                <?php $__currentLoopData = $unassigned; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <span><?php echo e($student->name); ?></span>
                        <form method="POST" action="<?php echo e(route('students.claim', $student)); ?>" class="d-flex gap-2">
                            <?php echo csrf_field(); ?>
                            <select name="opportunity_id" class="form-select form-select-sm">
                                <option value="">Choose program/journal&hellip;</option>
                                <?php $__currentLoopData = $opportunities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opportunity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($opportunity->id); ?>"><?php echo e($opportunity->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button class="btn btn-sm btn-outline-primary" type="submit">Claim</button>
                        </form>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="panel">
        <div class="panel-head">
            <div><h2>Students</h2><p>&nbsp;</p></div>
            <?php if(auth()->user()->isCounselor()): ?>
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-toggle="collapse" data-bs-target="#waComposer">
                    &#128172; Send Reminder
                </button>
            <?php endif; ?>
        </div>

        <?php if(auth()->user()->isCounselor()): ?>
            <div class="collapse" id="waComposer">
                <div class="p-3 border-bottom" style="background:#F0FBF7">
                    <textarea id="waMessage" class="form-control mb-2" rows="2">Hi {name}, reminder that your {program} deadline is coming up — let's make sure everything is submitted on time.</textarea>
                    <div class="d-flex gap-2 align-items-center flex-wrap">
                        <button id="waSendBtn" class="btn btn-sm btn-primary" type="button">Send via WhatsApp to Selected</button>
                        <span id="waCount" class="text-muted small">0 selected</span>
                    </div>
                    <div id="waConfirm" class="small text-success mt-2" style="display:none"></div>
                </div>
            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <?php if(auth()->user()->isCounselor()): ?>
                            <th class="check-col"><input type="checkbox" id="checkAll"></th>
                        <?php endif; ?>
                        <th>Student</th>
                        <?php if(auth()->user()->hasBackOfficeAccess()): ?>
                            <th>Counselor</th>
                        <?php endif; ?>
                        <th>Program</th>
                        <th>Application</th>
                        <th>Fee</th>
                        <th>Visa</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $appClass = match($student->app_stage) {
                                'Accepted' => 'teal',
                                'Rejected' => 'coral',
                                'Not Applied' => 'gray',
                                default => 'amber',
                            };
                            $visaClass = match($student->visa_stage) {
                                'Visa Approved', 'Traveling' => 'teal',
                                'Visa Rejected' => 'coral',
                                'Not Started' => 'gray',
                                default => 'amber',
                            };
                        ?>
                        <tr data-name="<?php echo e($student->name); ?>" data-program="<?php echo e($student->opportunity->name ?? ''); ?>">
                            <?php if(auth()->user()->isCounselor()): ?>
                                <td><input type="checkbox" class="student-check" value="<?php echo e($student->id); ?>"></td>
                            <?php endif; ?>
                            <td class="name-cell"><?php echo e($student->name); ?></td>
                            <?php if(auth()->user()->hasBackOfficeAccess()): ?>
                                <td><?php echo e($student->counselor->name ?? ($student->partner ? 'Partner: '.$student->partner->name : '—')); ?></td>
                            <?php endif; ?>
                            <td><?php echo e($student->opportunity->name ?? '—'); ?></td>
                            <td>
                                <span class="chip app-stage-chip <?php echo e($appClass); ?>"
                                      data-url="<?php echo e(route('students.cycle-app-stage', $student)); ?>">
                                    <?php echo e($student->app_stage); ?>

                                </span>
                            </td>
                            <td class="date-cell fee-date"><?php echo e($student->fee_date?->toDateString() ?? '—'); ?></td>
                            <td>
                                <span class="chip visa-stage-chip <?php echo e($visaClass); ?>"
                                      data-url="<?php echo e(route('students.cycle-visa-stage', $student)); ?>">
                                    <?php echo e($student->visa_stage); ?>

                                </span>
                                <div class="sub-cell visa-date">
                                    <?php if($student->visa_date): ?> Filed <?php echo e($student->visa_date->toDateString()); ?> <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="7" class="empty-state">No students yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(function () {
        const allColors = ['teal', 'coral', 'gray', 'amber'];
        const appColors = { Accepted: 'teal', Rejected: 'coral', 'Not Applied': 'gray' };
        const visaColors = { 'Visa Approved': 'teal', 'Traveling': 'teal', 'Visa Rejected': 'coral', 'Not Started': 'gray' };

        $(document).on('click', '.app-stage-chip', function () {
            const $chip = $(this);
            $.ajax({ url: $chip.data('url'), method: 'PATCH', success: function (data) {
                $chip.text(data.app_stage);
                $chip.removeClass(allColors.join(' ')).addClass(appColors[data.app_stage] || 'amber');
            }});
        });

        $(document).on('click', '.visa-stage-chip', function () {
            const $chip = $(this);
            $.ajax({ url: $chip.data('url'), method: 'PATCH', success: function (data) {
                $chip.text(data.visa_stage);
                $chip.removeClass(allColors.join(' ')).addClass(visaColors[data.visa_stage] || 'amber');
                const $row = $chip.closest('tr');
                if (data.fee_date) $row.find('.fee-date').text(data.fee_date);
                if (data.visa_date) $row.find('.visa-date').text('Filed ' + data.visa_date);
            }});
        });

        $('#checkAll').on('click', function () {
            $('.student-check').prop('checked', $(this).prop('checked'));
            updateWaCount();
        });
        $(document).on('click', '.student-check', updateWaCount);

        function updateWaCount() {
            $('#waCount').text($('.student-check:checked').length + ' selected');
        }

        $('#waSendBtn').on('click', function () {
            const names = $('.student-check:checked').map(function () {
                return $(this).closest('tr').data('name');
            }).get();
            if (names.length === 0) return;
            $('#waConfirm').show().text('✓ Sent to ' + names.length + ': ' + names.join(', ') + ' — (demo only; connect WhatsApp Business API to send for real)');
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\guiders\resources\views/students/index.blade.php ENDPATH**/ ?>