<?php $__empty_1 = true; $__currentLoopData = $opportunities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opportunity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php $days = $opportunity->daysLeft(); ?>
    <div class="board-row">
        <div>
            <div class="board-prog"><?php echo e($opportunity->name); ?></div>
            <div class="board-req"><?php echo e($opportunity->requirements); ?></div>
            <div class="board-meta">
                <span class="cost-tag"><?php echo e($opportunity->currency); ?> <?php echo e(number_format($opportunity->cost, 0)); ?></span>
                <?php if($opportunity->official_link): ?>
                    <a href="<?php echo e($opportunity->official_link); ?>" target="_blank" rel="noopener" class="board-link">Official &#8599;</a>
                <?php endif; ?>
                <?php if($opportunity->application_link): ?>
                    <a href="<?php echo e($opportunity->application_link); ?>" target="_blank" rel="noopener" class="board-link">Apply &#8599;</a>
                <?php endif; ?>
                <span class="board-link download-package"
                      data-name="<?php echo e($opportunity->name); ?>"
                      data-country="<?php echo e($opportunity->country); ?>"
                      data-type="<?php echo e($opportunity->type === 'study_abroad' ? 'Study Abroad' : 'Research Publication'); ?>"
                      data-deadline="<?php echo e($opportunity->deadline->toDateString()); ?>"
                      data-requirements="<?php echo e($opportunity->requirements); ?>"
                      data-cost="<?php echo e($opportunity->currency); ?> <?php echo e(number_format($opportunity->cost, 2)); ?>"
                      data-guidance="<?php echo e($opportunity->guidance); ?>"
                      data-official="<?php echo e($opportunity->official_link); ?>"
                      data-application="<?php echo e($opportunity->application_link); ?>">
                    Download Package &#11015;
                </span>
            </div>
        </div>
        <div>
            <span class="type-tag <?php echo e($opportunity->type === 'study_abroad' ? 'sa' : 'rp'); ?>">
                <?php echo e($opportunity->type === 'study_abroad' ? 'STUDY' : 'PAPER'); ?>

            </span>
        </div>
        <div class="board-country"><?php echo e($opportunity->country); ?></div>
        <div class="flap"><?php echo e($opportunity->deadline->toDateString()); ?></div>
        <div class="countdown <?php echo e($days < 0 ? 'late' : ($days <= 14 ? 'soon' : 'ok')); ?>">
            <?php echo e($days < 0 ? 'T+'.abs($days).'D LATE' : ($days === 0 ? 'TODAY' : 'T-'.$days.'D')); ?>

        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="board-empty">No opportunities match your search.</div>
<?php endif; ?>
<?php /**PATH D:\guiders\resources\views/opportunities/_rows.blade.php ENDPATH**/ ?>