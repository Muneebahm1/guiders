<?php if($opportunities->isEmpty()): ?>
    <div class="board-empty">No matching programs within that budget.</div>
<?php else: ?>
    <div class="board-row header">
        <div>Program / Journal</div><div>Type</div><div>Country</div><div>Cost</div><div>Deadline</div>
    </div>
    <?php $__currentLoopData = $opportunities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opportunity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $days = $opportunity->daysLeft(); ?>
        <div class="board-row">
            <div>
                <div class="board-prog"><?php echo e($opportunity->name); ?></div>
                <div class="board-req"><?php echo e($opportunity->requirements); ?></div>
            </div>
            <div>
                <span class="type-tag <?php echo e($opportunity->type === 'study_abroad' ? 'sa' : 'rp'); ?>">
                    <?php echo e($opportunity->type === 'study_abroad' ? 'STUDY' : 'PAPER'); ?>

                </span>
            </div>
            <div class="board-country"><?php echo e($opportunity->country); ?></div>
            <div class="flap"><?php echo e($opportunity->currency); ?> <?php echo e(number_format($opportunity->cost, 0)); ?></div>
            <div class="countdown <?php echo e($days < 0 ? 'late' : ($days <= 14 ? 'soon' : 'ok')); ?>">
                <?php echo e($days < 0 ? 'T+'.abs($days).'D LATE' : ($days === 0 ? 'TODAY' : 'T-'.$days.'D')); ?>

            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /home/u943754902/domains/deekod.com/public_html/guiders/resources/views/suggest/_results.blade.php ENDPATH**/ ?>