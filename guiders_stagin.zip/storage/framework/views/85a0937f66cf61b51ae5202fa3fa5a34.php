<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body style="margin:0;padding:0;background:#F5F5F0;font-family:Arial,Helvetica,sans-serif;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#F5F5F0;padding:24px 0;">
        <tr>
            <td align="center">
                <table role="presentation" width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:6px;overflow:hidden;">
                    <tr>
                        <td style="background:#1F4E86;padding:18px 24px;">
                            <span style="color:#ffffff;font-size:16px;font-weight:bold;">THE GUIDERS</span>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:24px;color:#1B1F22;font-size:14px;line-height:1.6;">
                            <?php if($forLead): ?>
                                <p>Hi <?php echo e($lead->name); ?>,</p>
                                <p>We've received your document. Here's a quick confirmation:</p>
                            <?php else: ?>
                                <p>A document was uploaded for <strong><?php echo e($lead->name); ?></strong> by <?php echo e($document->counselor->name); ?>.</p>
                            <?php endif; ?>

                            <table role="presentation" width="100%" cellpadding="4" cellspacing="0" style="font-size:13px;margin:16px 0;border-collapse:collapse;">
                                <tr><td style="color:#5B6570;width:140px;">Document type</td><td><strong><?php echo e($document->document_type); ?></strong></td></tr>
                                <tr><td style="color:#5B6570;">File name</td><td><strong><?php echo e($document->file_name); ?></strong></td></tr>
                                <tr><td style="color:#5B6570;">Uploaded on</td><td><strong><?php echo e($document->created_at->format('M j, Y g:i A')); ?></strong></td></tr>
                                <?php if($document->notes): ?>
                                    <tr><td style="color:#5B6570;">Notes</td><td><?php echo e($document->notes); ?></td></tr>
                                <?php endif; ?>
                            </table>

                            <?php if($forLead): ?>
                                <p>If this wasn't expected or you have questions, please contact your counselor.</p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:0 24px 24px;color:#5B6570;font-size:12px;">
                            The Guiders Overseas Educational Services
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
<?php /**PATH D:\guiders\resources\views/emails/lead-document.blade.php ENDPATH**/ ?>