<?php $__empty_1 = true; $__currentLoopData = $opportunities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opportunity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php $days = $opportunity->daysLeft(); ?>
    <div class="board-row">
        <div>
            <div class="board-prog"><?php echo e($opportunity->name); ?></div>
            <div class="board-req"><?php echo e($opportunity->requirements); ?></div>
            <div class="board-meta">
                <span class="cost-tag"><?php echo e($opportunity->currency); ?> <?php echo e(number_format($opportunity->cost, 0)); ?></span>
                <?php if(!auth()->user()->isCounselor()): ?>
                    <?php if($opportunity->official_link): ?>
                        <a href="<?php echo e($opportunity->official_link); ?>" target="_blank" rel="noopener" class="board-link">Official &#8599;</a>
                    <?php endif; ?>
                    <?php if($opportunity->application_link): ?>
                        <a href="<?php echo e($opportunity->application_link); ?>" target="_blank" rel="noopener" class="board-link">Apply &#8599;</a>
                    <?php endif; ?>
                <?php endif; ?>
                <span class="board-link download-package"
                      data-name="<?php echo e($opportunity->name); ?>"
                      data-country="<?php echo e($opportunity->country); ?>"
                      data-type="<?php echo e($opportunity->type === 'study_abroad' ? 'Study Abroad' : 'Research Publication'); ?>"
                      data-deadline="<?php echo e($opportunity->deadline->toDateString()); ?>"
                      data-requirements="<?php echo e($opportunity->requirements); ?>"
                      data-cost="<?php echo e($opportunity->currency); ?> <?php echo e(number_format($opportunity->cost, 2)); ?>"
                      data-guidance="<?php echo e($opportunity->guidance); ?>"
                      data-official="<?php echo e($opportunity->official_link); ?>"
                      data-application="<?php echo e($opportunity->application_link); ?>">
                    Download Package &#11015;
                </span>
            </div>
            <?php if(auth()->user()->isAdmin() || auth()->user()->isProcessingTeam()): ?>
                <div class="sessions-section" style="margin-top: 8px; padding-top: 8px; border-top: 1px solid var(--line);">
                    <div style="font-size: 11px; color: var(--muted); margin-bottom: 4px;">Sessions:</div>
                    <?php if($opportunity->sessions->isNotEmpty()): ?>
                        <?php $__currentLoopData = $opportunity->sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="session-item" style="font-size: 11px; padding: 2px 0;">
                                <span><?php echo e($session->session_name); ?></span>
                                <?php if($session->university): ?> <span style="color: var(--muted);">· <?php echo e($session->university); ?></span> <?php endif; ?>
                                <?php if($session->country): ?> <span style="color: var(--muted);">· <?php echo e($session->country); ?></span> <?php endif; ?>
                                <?php if($session->deadline): ?> <span style="color: var(--muted);">· <?php echo e($session->deadline->toDateString()); ?></span> <?php endif; ?>
                                <form method="POST" action="<?php echo e(route('opportunities.sessions.destroy', $session)); ?>" style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" style="background: none; border: none; color: #dc3545; cursor: pointer; font-size: 10px; margin-left: 4px;">✕</button>
                                </form>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div style="font-size: 11px; color: var(--muted);">No sessions added</div>
                    <?php endif; ?>
                    <button type="button" class="btn btn-outline-secondary btn-sm" style="font-size: 10px; padding: 2px 6px; margin-top: 4px;" data-bs-toggle="collapse" data-bs-target="#sessionForm-<?php echo e($opportunity->id); ?>">+ Add Session</button>
                    <div class="collapse" id="sessionForm-<?php echo e($opportunity->id); ?>" style="margin-top: 4px;">
                        <form method="POST" action="<?php echo e(route('opportunities.sessions.store', $opportunity)); ?>" style="display: flex; gap: 4px; flex-wrap: wrap;">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="session_name" placeholder="Session name (e.g., Fall 2026)" style="flex: 1; min-width: 120px; padding: 4px 8px; border: 1px solid var(--line); border-radius: 4px; font-size: 11px;" required>
                            <input type="text" name="university" placeholder="University" style="flex: 1; min-width: 100px; padding: 4px 8px; border: 1px solid var(--line); border-radius: 4px; font-size: 11px;">
                            <input type="text" name="country" placeholder="Country" style="flex: 1; min-width: 80px; padding: 4px 8px; border: 1px solid var(--line); border-radius: 4px; font-size: 11px;">
                            <input type="date" name="deadline" style="flex: 1; min-width: 100px; padding: 4px 8px; border: 1px solid var(--line); border-radius: 4px; font-size: 11px;">
                            <button type="submit" class="btn btn-primary btn-sm" style="font-size: 10px; padding: 4px 8px;">Add</button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <div>
            <span class="type-tag <?php echo e($opportunity->type === 'study_abroad' ? 'sa' : 'rp'); ?>">
                <?php echo e($opportunity->type === 'study_abroad' ? 'STUDY' : 'PAPER'); ?>

            </span>
        </div>
        <div class="board-country"><?php echo e($opportunity->country); ?></div>
        <div class="flap"><?php echo e($opportunity->deadline->toDateString()); ?></div>
        <?php if(!auth()->user()->isCounselor()): ?>
            <div class="countdown <?php echo e($days < 0 ? 'late' : ($days <= 14 ? 'soon' : 'ok')); ?>">
                <?php echo e($days < 0 ? 'T+'.abs($days).'D LATE' : ($days === 0 ? 'TODAY' : 'T-'.$days.'D')); ?>

            </div>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="board-empty">No opportunities match your search.</div>
<?php endif; ?>
<?php /**PATH D:\guiders\resources\views/opportunities/_rows.blade.php ENDPATH**/ ?>