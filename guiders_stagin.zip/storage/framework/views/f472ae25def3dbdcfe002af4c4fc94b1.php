<?php if(($reminders ?? collect())->isNotEmpty()): ?>
    <div class="alert alert-warning" id="reminderPopup">
        <strong>Reminders</strong>
        <ul class="mb-0 ps-3">
            <?php $__currentLoopData = $reminders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reminder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($reminder); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH D:\guiders\resources\views/partials/_reminder_banner.blade.php ENDPATH**/ ?>